/** Calendar selection, not a physiological cutoff. Missing requested history is
 * never replaced by newer sessions. Local calendar dates cross UTC boundaries. */
export const requestsCalendarPeriod=(question:string)=>/前年|去年|今年|上个月|20\d{2}年|\d{4}-\d{2}-\d{2}/.test(question)
export function contextPeriod(question:string, day:string, timeZone:string) {
 const year=Number(day.slice(0,4)), month=Number(day.slice(5,7))
 const days=[...question.matchAll(/\d{4}-\d{2}-\d{2}/g)].map(m=>m[0])
 const years=new Set<number>()
 if(/前年/.test(question))years.add(year-2)
 if(/去年/.test(question))years.add(year-1)
 if(/今年/.test(question))years.add(year)
 for(const m of question.matchAll(/(20\d{2})年/g))years.add(Number(m[1]))
 const lastMonth=month===1?`${year-1}-12`:`${year}-${String(month-1).padStart(2,'0')}`
 const monthPrefix=/上个月/.test(question)?lastMonth:null
 const label=days.length?days.join('、'):years.size?[...years].sort().join('、')+'年':monthPrefix??null
 let formatter:Intl.DateTimeFormat|undefined
 try{formatter=new Intl.DateTimeFormat('en-CA',{timeZone,year:'numeric',month:'2-digit',day:'2-digit'})}catch{/* Preserve the recorded UTC day if a legacy zone cannot be resolved. */}
 const cache=new Map<string,string>()
 const localDate=(occurredAt:string,calendarDay=false)=>{
  if(calendarDay)return occurredAt.slice(0,10)
  if(cache.has(occurredAt))return cache.get(occurredAt)!
  try {
   if(!formatter)return occurredAt.slice(0,10)
   const p=formatter.formatToParts(new Date(occurredAt))
   const result=['year','month','day'].map(type=>p.find(v=>v.type===type)?.value).join('-')
   cache.set(occurredAt,result);return result
  } catch { return occurredAt.slice(0,10) }
 }
 return {label, matches:(at:string,calendarDay=false)=>{
  const d=localDate(at,calendarDay)
  return days.length?days.includes(d):years.size?years.has(Number(d.slice(0,4))):monthPrefix?d.startsWith(monthPrefix):true
 }, group:(at:string)=>days.length?localDate(at):years.size?localDate(at).slice(0,4):'all'}
}
