# 给 GPT Work 的接续入口

这是小交接包，不是完整源码包。用户现在只要求交接，不再要求重新发送全量源码。

同工作区先读 /workspace/fangkun-phased-plan-20261028/CURRENT-TASK.md，直接使用 /workspace/fangkun-20261028 已保存改动，不重复覆盖。

独立工作区：从 Fang-Molen/fangkun 的 codex/coaching-repairs-20261028 获取基线92632540c8cd42267461d42403786bec2a2281eb，再读 CURRENT-TASK.md、MANIFEST.json。changes/包含本轮所有未提交的公开代码/文档/证据。逐文件先比较 baseSha256 和 sha256；本地不同于两者时应整合冲突，不直接覆盖。基线之后远端有更新也要保留整合，不强制回退。

源代码和测试尚有未完成项；具体顺序以CURRENT-TASK为准。不要重复开发，不重读全部历史，不把旧PASS冒称最终闭环成功。未推送、未部署、未付费调用。
