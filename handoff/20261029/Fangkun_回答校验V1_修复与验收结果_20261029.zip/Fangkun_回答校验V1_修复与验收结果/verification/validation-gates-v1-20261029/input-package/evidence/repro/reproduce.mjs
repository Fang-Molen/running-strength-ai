// Independent, offline boundary probes. Imports the unchanged source in the uploaded package.
// No model, network, credentials, database or App writes.
import {questionCalculations as f} from './question-calculation.ts';
import {writeFileSync} from 'node:fs';
const scenarios=[
 {id:'RV01',question:'甲跑5公里25分钟，乙跑5公里25分钟。谁更快？',prior:[],expected:'两次平均配速相同，均5:00/km，不得选出更快者',bad:s=>s.includes('甲用时每公里较少、更快')},
 {id:'RV02',question:'甲跑5公里用时24.99分钟，乙跑5公里用时25分钟。谁更快？',prior:[],expected:'299.88秒/km按整秒显示5:00/km；可说明原始精度甲略快；不得显示4:60',bad:s=>s.includes('4:60/km')},
 {id:'RV03',question:'第4组实际是28秒，其他不变，请更新。',prior:['我完成4组，每组200米，成绩是30、31、32、33秒。','我刚才记错，第2组实际是29秒，其他不变。'],expected:'前次更正后总124秒，本轮变成30+29+32+28=119秒，保留第2组更正',bad:s=>s.includes('新总时间121秒')},
 {id:'RV04',question:'我做了4×300米，前3组是58秒、60秒、61秒，第4组已完成但没记录时间。',prior:[],expected:'已完成1200米；已知前三组179秒；整课工作时间未知；完成状态明确',bad:s=>s.includes('已知完成900米')&&s.includes('其余组完成状态未知')}
];
const results=scenarios.map(({bad,...c})=>{const output=f(c.question,c.prior);return {...c,actual:output,status:bad(JSON.stringify(output))?'BUG_REPRODUCED':'NOT_REPRODUCED_REVIEW_REQUIRED'}});
writeFileSync(new URL('./observed.json',import.meta.url),JSON.stringify({scope:'PURE_FUNCTION_OFFLINE_NOT_APP_OR_MODEL_RUN',node:process.version,results},null,2)+'\n');
console.log(JSON.stringify({probes:results.length,bugs_reproduced:results.filter(r=>r.status==='BUG_REPRODUCED').length,not_model_tests:true}));
