import { CoachWeeklyBootstrap } from '@/components/coach-weekly-panel';
import { CoachSuggestionsPanel, useSuggestionCount } from "@/components/coach-suggestions-panel";
import {PlanCourseDateSheet} from './plan-course-date-sheet'
import { OnlineFeaturesSettings } from "./online-features-settings";
import { startC03FollowupRuntime } from '@/lib/coach/c03/runtime';
import { onlineFeatures } from "@/lib/ui/online-features";
import { installChunkRecovery, isChunkError, recoverFromChunkError } from "@/lib/chunk-recover";
import { HomeDashboard } from "@/components/home-dashboard";
import { GarminLog } from "@/components/garmin-log";
import { lazy, Suspense } from "react";
const RunningTechniqueLibrary = lazy(() => import("@/components/running-technique-library").catch((e) => { if (isChunkError(e)) void recoverFromChunkError(); throw e; }));
const BodyLabPanel = lazy(() => import("@/components/bodylab/bodylab-panel").catch((e) => { if (isChunkError(e)) void recoverFromChunkError(); throw e; }));
import { exportFeedback } from "@/components/coach-feedback";
import { AthletePanel, BackupCenter, HealthPanel, PrivacyPanel, SettingsMenu, type SettingsPane } from "@/components/settings-center";
import { DeviceSyncCenter } from "@/components/device-sync-center";
import { DEVICE_SYNC_OPEN, normalizeSyncRequest, openDeviceSync, readSyncCallback, type SyncCallback, type SyncRequest } from "@/lib/ui/device-sync-navigation";
import { Plan400Cycle, Plan400TodayCard, Plan400DayHost, TempTrainingList, ensurePlan400Entry, PLAN400_GUIDED_EVT, openPlan400Day } from "@/components/plan400";
import { occurrenceVoided } from "@/lib/core/training-correction";
import { RunImportPrompt } from "@/components/plan400-parts";
import { loadTrainingActivities } from "@/lib/ui/training-read-model";
import { todayCoordinationParts, todayPartsText, type TodayPart } from "@/lib/ui/coach-coordination-view";
import { dayKind, hasRunPart, hasStrength, type V4Day } from "@/lib/ui/plan400-view";
import { matchesScheduledPlanPane } from "@/lib/ui/plan-training-filter";
import { hasActivePlan, planDay, PLAN_CHANGED_EVT } from "@/lib/plan/active-plan";
import { NoPlanCard, PlanImportPanel } from "@/components/plan-import";
import { importVault } from "@/lib/vault";
import { maybeAutoGarminSync } from "@/components/garmin-sync";
import { checkForNewVersion } from "@/lib/ui/app-version-check";
import { initVault } from "@/lib/vault";
import { retryPendingCorrectionReviews } from "@/lib/core/training-correction";
import { activateBulkStore, enterBulkDegradedIfMigrated } from "@/lib/core/bulk-store";
import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { CATALOG, GROUPS, type ExerciseGroup } from "@/lib/strength/catalog";
import { bootCore, captureOriginalPlan, dispatchEvent } from "@/lib/core";
import { currentAthleteId, loadEvents, onAppEvent } from "@/lib/core/events";
import { offlinePrefetchUrls, serviceWorkerNavigationPlan, trainingExecutionOpen } from "@/lib/ui/sw-reload";
import { CoachSheet } from "@/components/coach-sheet";
import { CoachCoordinationHub } from "@/components/coach-coordination-hub";
import {applyStrengthReduction,rollbackStrengthReduction,type StrengthProposal,type StrengthControl} from "@/lib/core/coach-strength-plan-control";
import {commitControlledStrengthPlan} from "@/lib/core/coach-strength-plan-storage";
import type {CoachStrengthAction} from "@/components/coach-strength-edit-panel";
import { BodyCenter, type BodyPane } from "@/components/body-center";
import { AppearanceSettings } from "@/components/appearance-settings";
import { FloatingPet } from "@/components/pet/floating-pet";
import {PetCaptureHost} from '@/components/pet/pet-capture';
import {openPetCapture} from '@/lib/ui/pet-capture-navigation';
import { readCharacterTheme, writeCharacterTheme, getCharacterTheme, CHARACTER_THEME_BACKGROUND, CHARACTER_THEME_KEY, type CharacterThemeId } from "@/lib/ui/character-themes";
import { readWallpaper, writeWallpaper, type WallpaperId, readDisplayMode, writeDisplayMode, type DisplayMode } from "@/lib/ui/appearance";
import { readFontScale, writeFontScale, type FontScale } from "@/lib/ui/font-scale-v89";
import { TrainingLogPage } from "@/components/training-log-v76";
import { TrainingEvidencePanel } from "@/components/training-evidence-panel";
import { AbilityRadarCard } from "@/components/ability-radar-card";
import { Activity, CalendarDays, ChevronDown, ChevronLeft, ChevronUp, ClipboardList, Database, Dumbbell, Heart, House, Footprints, MessageCircle, Palette, Plus, Scale, Settings, Target, Trash2, UserRound, Utensils, Watch, X } from "lucide-react";
import { DayCard } from "@/components/day-card";
import { TodayBoard } from "@/components/today-board";
import { PlanSourceCard } from "@/components/plan-source";
import { DietPage } from "@/components/fuel-guide";
import { ReviewPanel } from "@/components/review-card";
import { HealthLinkSheet, HomeEditor, useLocalReminders, HomeHeader, LogMetricsPanel, Onboarding, QuickLog, SettingsHub } from "@/components/r8";
import { ONBOARD_KEY, ONBOARD_SKIPPED_KEY } from "@/lib/ui/first-run";
import { LAYOUT_DEFAULT, loadLayout, type Layout, type QuickId } from "@/lib/ui/home-layout";
import { readLaunchParams } from "@/lib/ui/shortcut-link";
import { OVERRIDE_KEY, type Override } from "@/lib/ui/day-override";
import { loadSettings } from "@/lib/ui/app-settings";
const localDayIso = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; };
import { AssessmentPanel } from "@/components/assessment-panel";
import { TrackSessionPanel } from "@/components/track-session";
import { TrainingDecisionCard } from "@/components/training-decision-card";
import { SessionOverview } from "@/components/session-overview";
import { TrainingImportSheet } from "@/components/training-import-sheet";
import { CoachPlanSheet } from "@/components/coach-plan-sheet";
import { FangShen } from "@/components/fang-shen";
import { ExerciseContent } from "@/components/exercise-content";
import { SessionBuilder } from "@/components/session-builder";
import { MuscleExplorerSheet } from "@/components/muscle-explorer";
import { ActionPicker } from "@/components/action-picker";
import { DemoSheet, type DemoAction } from "@/components/exercise-editor";
import { TrainingEditorSheet } from "@/components/training-editor-sheet";
import { SchedulePicker, ScheduledTraining } from "@/components/scheduled-training";
import { MuscleActionList } from "@/components/muscle-action-list";
import { loadSchedule, saveScheduledEntry, strengthEntry, runEntry } from "@/lib/ui/day-schedule";
import { syncScheduleProgressCoordinated as syncScheduleProgress } from "@/lib/ui/schedule-progress";
import { scheduleExecutionId, scheduledChoices } from "@/lib/ui/scheduled-execution";
import type { ScheduleEntry } from "@/lib/ui/day-schedule-rules";
import { listTrainingOccurrences } from "@/lib/core/occurrence";
import { Sheet as AppSheet } from "@/components/sheet";
import { LOCAL_MUSCLE_ACTIONS, type MuscleAction } from "@/lib/body/muscle-actions";
import { PLAN_KEY, appendSessionCompared, savePlanCompared } from "@/lib/strength/session-builder";
import { executionOf } from "@/lib/core/execution";
import { ProfileSheet } from "@/components/profile-sheet";
import { listTrackPlans, openTrackOccurrence, describeTrackPlan } from "@/lib/ui/running-workouts";
import { trackHomeView } from "@/lib/ui/running-workouts";
import { absorbFeel, loadCoach, saveCoach } from "@/lib/strength/coach";
import { emptyProfile, goalsFromProfile, loadProfile, profileFilled, profileSummary, saveProfile, withCoachGoals, type Profile } from "@/lib/strength/profile";
import { loadSupportingGoals, saveSupportingGoals } from "@/lib/ui/goal-portfolio";
import { collectLocalBackup, TRIAL_VERSION } from "@/lib/core/trial";
import { bodyTrend } from "@/lib/nutrition/body";
import { loadDay } from "@/lib/nutrition/day";
import { todayEaten } from "@/lib/nutrition/log";
import { DEFAULT_SPORT_GOAL, GOALS, SPORTS, homeVariant, loadSportGoal, saveSportGoal, type GoalId, type SportGoalPreference, type SportId } from "@/lib/ui/sport-goal";
import {
  PHASES,
  TEMPLATES,
  advanceCycle,
  blankPlan,
  customMove,
  displayName,
  ensureCycle,
  estimateMinutes,
  loadPlan,
  logSession,
  moveFromCatalog,
  phaseOf,
  savePlan,
  uid,
  weekReady,
  type Feel,
  type Move,
  type Plan,
} from "@/lib/strength/model";

const starter = ensureCycle(TEMPLATES.find((item) => item.id === "run")?.plan() ?? blankPlan());
const PLAN_SAVE_FAIL = "课表没有写入本机，原来的记录还在。可以再存一次，或打开个人与数据下载备份。"
const COACH_SAVE_FAIL = "教练记录没有写入本机，原来的记录还在。可以再存一次，或打开个人与数据下载备份。"

const FEELS: { id: Feel; label: string; hint: string }[] = [
  { id: "easy", label: "太轻松", hint: "都能做完，还能再多" },
  { id: "ok", label: "刚好", hint: "最后一两下有点吃力" },
  { id: "hard", label: "偏重", hint: "做不满，或做完腿很沉" },
  { id: "pain", label: "有不适", hint: "关节或某一下发疼，不是酸" },
  { id: "skip", label: "这周没练", hint: "这节先保持，不加减" },
];

/** v89.11.13：大块数据（各手表来源的日内样本、训练导入等）在 IndexedDB，渲染前先加载进内存（通常几十毫秒）。
 *  超过 4 秒还没好：已迁移过的用户进入降级（这些数据暂读为空、拒绝写入，绝不覆盖），其余数据照常可用。 */
function BulkGate({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    let done = false;
    const timer = setTimeout(() => { if (!done) { enterBulkDegradedIfMigrated(); setReady(true); } }, 4000);
    void activateBulkStore().catch(() => {}).finally(() => { done = true; clearTimeout(timer); setReady(true); });
    return () => clearTimeout(timer);
  }, []);
  return ready ? <>{children}</> : (
    <main className="grid min-h-dvh place-items-center bg-bg px-6 text-fg" role="status" aria-live="polite" data-testid="training-app" data-ready="false">
      <p className="text-sm text-muted">正在读取本地训练记录…</p>
    </main>
  );
}

export function StrengthApp() {
  return <BulkGate><StrengthAppInner /></BulkGate>;
}

function StrengthAppInner() {
  const suggestionCount = useSuggestionCount();
  useEffect(() => startC03FollowupRuntime(), []);
  const [bodyPane, setBodyPane] = useState<BodyPane>("recovery");
  const [, setDataRevision] = useState(0);
  useEffect(() => { try { onlineFeatures() } catch { /* storage unavailable */ } }, []); // v78 t473：联网功能默认全开，记录一次同意
  useEffect(() => {
    const refresh = () => setDataRevision(value => value + 1);
    const unsubscribe = onAppEvent(refresh);
    const onStorage = (event: StorageEvent) => { if (event.key == null || event.key.startsWith("fr255-")) refresh(); };
    window.addEventListener("storage", onStorage);
    return () => { unsubscribe(); window.removeEventListener("storage", onStorage); };
  }, []);
  const [plan, setPlan] = useState<Plan>(starter);
  const [wallpaper, setWallpaper] = useState<WallpaperId>("plain");
  const [characterTheme, setCharacterTheme] = useState<CharacterThemeId>("classic");
  const [displayMode, setDisplayMode] = useState<DisplayMode>("light");
  const [fontScale, setFontScale] = useState<FontScale>("standard");
  const [systemDark, setSystemDark] = useState(false);
  useEffect(() => {
    setWallpaper(readWallpaper(window.localStorage));
    setCharacterTheme(readCharacterTheme(window.localStorage));
    setDisplayMode(readDisplayMode(window.localStorage));
    setFontScale(readFontScale(window.localStorage));
    const media = window.matchMedia?.("(prefers-color-scheme: dark)");
    if (!media) return;
    const update = () => setSystemDark(media.matches);
    update();
    media.addEventListener?.("change", update);
    return () => media.removeEventListener?.("change", update);
  }, []);
  useEffect(() => {
    const refreshTheme = (event: StorageEvent) => {
      if (event.key === CHARACTER_THEME_KEY || event.key === null) setCharacterTheme(readCharacterTheme(window.localStorage));
    };
    window.addEventListener("storage", refreshTheme);
    return () => window.removeEventListener("storage", refreshTheme);
  }, []);
  useEffect(() => {
    const currentTheme = getCharacterTheme(characterTheme);
    const resolvedMode = displayMode === "system" ? (systemDark ? "dark" : "light") : displayMode;
    const themeColor = currentTheme ? CHARACTER_THEME_BACKGROUND[currentTheme.id][resolvedMode] : (resolvedMode === "dark" ? "#121314" : "#F7F6F2");
    document.querySelector('meta[name="theme-color"]')?.setAttribute("content", themeColor);
  }, [characterTheme, displayMode, systemDark]);
  useEffect(() => {
    document.documentElement.dataset.fkFontScale = fontScale;
    return () => { delete document.documentElement.dataset.fkFontScale; };
  }, [fontScale]);
  useEffect(() => {
    const refresh = () => setFontScale(readFontScale(window.localStorage));
    window.addEventListener('storage', refresh);
    window.addEventListener('pageshow', refresh);
    return () => { window.removeEventListener('storage', refresh); window.removeEventListener('pageshow', refresh); };
  }, []);
  const [active, setActive] = useState(0);
  const [workspaceOpen, setWorkspaceOpen] = useState(false);
  const [workspaceMounted, setWorkspaceMounted] = useState(false);
  const [courseChoice, setCourseChoice] = useState("");
  const [builderOpen, setBuilderOpen] = useState(false);
  const [muscleOpen, setMuscleOpen] = useState(false), [muscleDemo, setMuscleDemo] = useState<string | null>(null);
  const [hubPane, setHubPane] = useState<"run" | "lift">("run");
  const [pickerMuscle, setPickerMuscle] = useState(false), [pickerDemo, setPickerDemo] = useState<string | null>(null);
  const [selectedDate, setSelectedDate] = useState(localDayIso());
  const [courseDatesOpen,setCourseDatesOpen]=useState(false);
  const [calendar, setCalendar] = useState<ScheduleEntry[]>([]);
  const [timerPicker, setTimerPicker] = useState(false), [executionEntryId, setExecutionEntryId] = useState<string | null>(null);
  const [actionLibrary, setActionLibrary] = useState(false);
  const [techniqueLibrary, setTechniqueLibrary] = useState(false);
  const [trainingEditor, setTrainingEditor] = useState<{ date: string; initial?: ScheduleEntry; template?: ScheduleEntry; seedAction?: MuscleAction; initialType?: "run" | "strength"; openMuscleInitially?: boolean } | null>(null);
  const planRaw = useRef<string | null>(null);
  const builderSaving=useRef(false);
  const [planConflict, setPlanConflict] = useState("");
  const [ready, setReady] = useState(false);
  const [picker, setPicker] = useState(false);
  const [query, setQuery] = useState("");
  const [group, setGroup] = useState<ExerciseGroup | "全部">("全部");
  const [notice, setNotice] = useState("");
  const [offline, setOffline] = useState(false);
  const [offlineShellState, setOfflineShellState] = useState<"preparing" | "ready" | "unavailable">("preparing");
  const [planSaveFailed, setPlanSaveFailed] = useState(false);
  const [feedback, setFeedback] = useState(false);
  const [feel, setFeel] = useState<Feel>("ok");
  const [painIds, setPainIds] = useState<string[]>([]);
  const [feelNote, setFeelNote] = useState("");
  const [coachFocus, setCoachFocus] = useState<string | null>(null);
  const [coachLink, setCoachLink] = useState<"ask" | "bound" | "unbound">("ask");
  const [coachSeed, setCoachSeed] = useState<{ text: string; chip: string } | null>(null);
  const [formMove, setFormMove] = useState<Move | null>(null);
  const [profile, setProfile] = useState<Profile>(emptyProfile());
  const [profileOpen, setProfileOpen] = useState(false);
  const [trainingImportOpen, setTrainingImportOpen] = useState(false);
  const [planImportOpen, setPlanImportOpen] = useState(false);
  const [coachPlanOpen, setCoachPlanOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const prevTab = useRef<"today" | "plan" | "log" | "courses" | "body" | "diet">("today");
  const [settingsPane, setSettingsPaneRaw] = useState<SettingsPane>("menu");
  const [syncRequest, setSyncRequest] = useState<SyncRequest>({ mode: "accounts" });
  const [syncCallback, setSyncCallback] = useState<SyncCallback | null>(null);
  const settingsScroll = useRef<HTMLDivElement>(null); const menuScrollTop = useRef(0);
  const setSettingsPane = (p: SettingsPane) => { const el = settingsScroll.current; if (p !== "menu" && el) menuScrollTop.current = el.scrollTop; if (p === "sync" || p === "import") { setSyncRequest({ mode: p === "import" ? "files" : "accounts" }); setSyncCallback(null); } setSettingsPaneRaw(p === "import" ? "sync" : p); window.setTimeout(() => { if (settingsScroll.current) settingsScroll.current.scrollTop = p === "menu" ? menuScrollTop.current : 0; }, 0); };
  const [weekPeek, setWeekPeek] = useState<1 | 2 | 3 | 4 | null>(null);
  const [preference, setPreference] = useState<SportGoalPreference>(DEFAULT_SPORT_GOAL);
  const [supportingGoals, setSupportingGoals] = useState<GoalId[]>([]);
  const [weightText, setWeightText] = useState<string | null>(null);
  const [runKm, setRunKm] = useState<number | null>(null);
  const [kcal, setKcal] = useState<number | null>(null);
  const [goalSaveFailed, setGoalSaveFailed] = useState(false);
  useEffect(() => { void initVault().then(() => { const review = retryPendingCorrectionReviews(); if (review.pending > 0) setNotice("部分更正后的判断仍待重审，旧判断不会当作最新结果。"); }).catch(() => { setNotice("保险箱初始化或复核未完成；当前记录保留，请在备份与恢复中核对存储状态。"); }); }, []);
  const [dietSheet, setDietSheet] = useState(false);
  useEffect(() => { const go = () => { if (document.visibilityState === "visible") window.setTimeout(() => void checkForNewVersion(() => trainingExecutionOpen(loadEvents())).then((reloading) => { if (!reloading) return maybeAutoGarminSync(); }).catch(() => {}), 1500); }; go(); document.addEventListener("visibilitychange", go); window.addEventListener("pageshow", go); window.addEventListener("online", go); const iv = window.setInterval(() => { if (document.visibilityState === "visible") void maybeAutoGarminSync().catch(() => {}); }, 15 * 60e3 + 5000); return () => { document.removeEventListener("visibilitychange", go); window.removeEventListener("pageshow", go); window.removeEventListener("online", go); window.clearInterval(iv); }; }, []);
  const [planSrc, setPlanSrc] = useState<string>("400m-v4");
  useEffect(() => { try { const v = JSON.parse(localStorage.getItem("fk-plan-source-v1") || "{}").active; if (v) setPlanSrc(v); } catch { /* keep default */ } }, []);
  const setPlanSrcSaved = (v: string) => { setPlanSrc(v); try { const o = JSON.parse(localStorage.getItem("fk-plan-source-v1") || "{}"); localStorage.setItem("fk-plan-source-v1", JSON.stringify({ ...o, active: v, history: [...(o.history ?? []), { active: v, at: new Date().toISOString() }] })); } catch { /* storage full */ } };
  const [tab, setTab] = useState<"today" | "plan" | "log" | "courses" | "coach" | "body" | "diet">("today");
  const inTraining = tab === "plan" || tab === "log" || tab === "courses";
  const [homeRev, setHomeRev] = useState(0);
  const [dayOverride, setDayOverride] = useState<Override | null>(null);
  const [bandOn, setBandOn] = useState(true);
  const [firstRun, setFirstRun] = useState(false);
  const [homeLayout, setHomeLayout] = useState<Layout>(LAYOUT_DEFAULT);
  const [editHome, setEditHome] = useState(false);
  const [quickOpen, setQuickOpen] = useState<{ text: string; n: number } | null>(null);
  const [healthLink, setHealthLink] = useState<string | null>(null);
  const launchHandled = useRef(false);
  useEffect(() => {
    // Consume one launch once, including React's development effect replay.
    // A vendor return takes precedence over shortcut import, keeping one window.
    if (launchHandled.current) return;
    launchHandled.current = true;
    setHomeLayout(loadLayout());
    const result = readSyncCallback(location.search);
    if (result) { setSyncCallback(result); setSyncRequest({ mode: "accounts", provider: result.provider }); setSettingsPaneRaw("sync"); setSettingsOpen(true); history.replaceState(history.state, "", `${location.pathname}${result.cleanSearch}${location.hash}`); return; }
    const lp = readLaunchParams(location.search);
    if (lp.log != null) setQuickOpen({ text: lp.log, n: Date.now() });
    if (lp.health) setHealthLink(lp.health);
    if (lp.log != null || lp.health) history.replaceState(null, "", location.pathname);
  }, []);
  useEffect(() => { setFirstRun(!localStorage.getItem(ONBOARD_KEY) && !localStorage.getItem(ONBOARD_SKIPPED_KEY)); setBandOn(loadSettings().band); try { const o = JSON.parse(localStorage.getItem(OVERRIDE_KEY) ?? "null"); if (o?.date === localDayIso()) setDayOverride(o) } catch { /* ignore */ } }, [tab]);
  const [planLens, setPlanLens] = useState<"all" | "run" | "lift">("all");
  const [clockLabel, setClockLabel] = useState("");
  const [showPlanTools, setShowPlanTools] = useState(false);
  const [planMore, setPlanMore] = useState(false);
  const [editorOpen, setEditorOpen] = useState(false);
  const trainingDecision = useRef<string | null>(null);
  useEffect(() => {
    const refresh = async () => { await syncScheduleProgress(); setCalendar(loadSchedule().entries); setHomeRev(n => n + 1); };
    refresh(); const unsubscribe = onAppEvent(refresh);
    window.addEventListener('fk-training-corrected', refresh); window.addEventListener('fk-schedule-changed', refresh); window.addEventListener('storage', refresh);
    return () => { unsubscribe(); window.removeEventListener('fk-training-corrected', refresh); window.removeEventListener('fk-schedule-changed', refresh); window.removeEventListener('storage', refresh); };
  }, []);
  const openScheduled = (entry: ScheduleEntry) => { setCalendar(loadSchedule().entries); setTimerPicker(false); setExecutionEntryId(entry.id); };
  // Reserve space for the coach header, tabs and live offline/preparation notice.
  useEffect(() => {
    const root = document.documentElement;
    const measure = () => {
      const h = document.querySelector<HTMLElement>(".ui03-header"), b = document.querySelector<HTMLElement>(".fk-coach-shell .fk-coach-bar");
      root.style.setProperty("--fk-head-h", `${Math.round(h?.getBoundingClientRect().height ?? 0)}px`);
      root.style.setProperty("--fk-coach-bar-h", `${Math.round(b?.getBoundingClientRect().height ?? 0)}px`);
      const noticeHeight = [...document.querySelectorAll<HTMLElement>(".fk-coach-shell > p")].reduce((sum, notice) => sum + notice.getBoundingClientRect().height, 0);
      root.style.setProperty("--fk-coach-notice-h", `${Math.ceil(noticeHeight)}px`);
    };
    const ro = new ResizeObserver(measure);
    const watch = () => {
      ro.disconnect();
      document.querySelectorAll<HTMLElement>(".ui03-header, .fk-coach-shell .fk-coach-bar, .fk-coach-shell > p").forEach(e => ro.observe(e));
      measure();
    };
    watch(); const t = setTimeout(watch, 300);
    return () => { clearTimeout(t); ro.disconnect(); };
  }, [tab, offline, offlineShellState]);
  useEffect(() => { const h = (event: Event) => { setSyncRequest(normalizeSyncRequest((event as CustomEvent).detail)); setSyncCallback(null); setSettingsPaneRaw("sync"); setSettingsOpen(true); window.setTimeout(() => settingsScroll.current?.scrollTo({ top: 0 }), 0); }; window.addEventListener(DEVICE_SYNC_OPEN, h); return () => window.removeEventListener(DEVICE_SYNC_OPEN, h); }, []);
  useEffect(() => { const h = () => { setTab("body"); setTimeout(() => document.getElementById("fk-intraday")?.scrollIntoView({ block: "start", behavior: "smooth" }), 120); }; window.addEventListener("fk-open-intraday", h); return () => window.removeEventListener("fk-open-intraday", h); }, []);
  useEffect(() => { const h = (ev: Event) => { const id = (ev as CustomEvent<string>).detail; const all = loadSchedule().entries; if (all.some(e => e.id === id)) { setCalendar(all); setTimerPicker(false); setExecutionEntryId(id); } }; window.addEventListener("fk-open-scheduled", h); return () => window.removeEventListener("fk-open-scheduled", h); }, []);
  const resumeSession = (id: string) => {
    const e = loadSchedule().entries.find(e => [scheduleExecutionId(e.id, 'strength'), scheduleExecutionId(e.id, 'run')].includes(id));
    if (e) { openScheduled(e); return; }
    const i = plan.sessions.findIndex(s => s.id === id);
    if (i >= 0) { setActive(i); setCourseChoice(`lift:${id}`); setWorkspaceMounted(true); setWorkspaceOpen(true); setTab('today'); return; }
    if (listTrackPlans().some(p => p.planId === id)) { setCourseChoice(`run:${id}`); setWorkspaceMounted(true); setWorkspaceOpen(true); setTab('today'); return; }
    setNotice('进行中的课程已有记录，但对应安排暂不可读。请在日志核对，未另开课程。');
  };
  const editScheduled = (entry: ScheduleEntry) => {
    const active = listTrainingOccurrences().some(o => o.lifecycle === 'IN_PROGRESS' && [scheduleExecutionId(entry.id, 'strength'), scheduleExecutionId(entry.id, 'run')].includes(o.sessionId));
    if (active) { setNotice('这节训练正在执行，当前组和休息已保留。请结束本课次后再修改日期、类型或训练参数。'); return; }
    setTrainingEditor({ date: entry.date, initial: entry });
  };
  // v81（t510–t512）：「计时」按当天情况走同一个逐组引导：进行中的先继续；今天是 V4 课就先确保有可执行条目；
  // 当天只有一节 → 直接打开；多节 → 让用户选；一节都没有 → 选择页里只给普通计时器。
  const openTimer = async () => {
    const active = listTrainingOccurrences().filter(o => o.lifecycle === 'IN_PROGRESS' && !occurrenceVoided(o.trainingOccurrenceId));
    if (active.length === 1) { resumeSession(active[0].sessionId); return; }
    if (planSrc === '400m-v4' && selectedDate === todayIso) await ensurePlan400Entry(todayIso).catch(() => null);
    const all = loadSchedule().entries; setCalendar(all);
    const choices = scheduledChoices(all, selectedDate);
    if (choices.length === 1) openScheduled(choices[0]); else setTimerPicker(true);
  };
  useEffect(() => { const h = (ev: Event) => { const det = (ev as CustomEvent<{ date: string; handled: boolean }>).detail; det.handled = true; void (async () => {
    const active = listTrainingOccurrences().filter(o => o.lifecycle === 'IN_PROGRESS' && !occurrenceVoided(o.trainingOccurrenceId) && o.sessionId.startsWith(`scheduled:plan400:${det.date}:`));
    if (active.length) { resumeSession(active[0].sessionId); return; }
    const r = await ensurePlan400Entry(det.date).catch(() => ({ id: null }));
    const all = loadSchedule().entries; setCalendar(all);
    if (r.id && all.some(e => e.id === r.id)) { setTimerPicker(false); setExecutionEntryId(r.id); } else openPlan400Day(det.date, 'during');
  })(); }; window.addEventListener(PLAN400_GUIDED_EVT, h); return () => window.removeEventListener(PLAN400_GUIDED_EVT, h); }, []);
  const templateEntry = (id: string): ScheduleEntry | undefined => {
    const s = plan.sessions.find(s => s.id === id); if (!s) return;
    return { ...strengthEntry(s, selectedDate, 'custom'), title: s.name, exercises: s.moves.map(m => ({ id: uid(), catalogId: m.catalogId, name: displayName(m), sets: String(m.sets), reps: String(m.amount), weight: String(m.weightKg), rpe: '', unit: m.mode === 'seconds' ? 'sec' : 'reps', restSec: m.restSec })) };
  };


  useEffect(() => {
    bootCore();
    planRaw.current = window.localStorage.getItem(PLAN_KEY);
    const saved = loadPlan();
    if (saved) setPlan(saved);
    else setPlan(starter);
    setReady(true);
    setClockLabel(new Intl.DateTimeFormat("zh-CN", { month: "long", day: "numeric", weekday: "short" }).format(new Date()));
    setProfile(loadProfile());
    const loadedPreference = loadSportGoal();
    setPreference(loadedPreference);
    setSupportingGoals(loadSupportingGoals(localStorage, loadedPreference.primaryGoal));
  }, []);

  useEffect(() => {
    const trend = bodyTrend();
    setWeightText(trend.latest ? `${trend.latest.weight} 公斤${trend.latest.fat != null ? `，脂肪率 ${trend.latest.fat}%` : ""}` : null);
    const day = loadDay();
    const km = day.runs.reduce((sum, run) => sum + run.km, 0);
    setRunKm(day.runs.length ? Number(km.toFixed(2)) : null);
    const eaten = todayEaten();
    setKcal(eaten > 0 ? eaten : null);
  }, [preference, tab]);

  useEffect(() => {
    if (!ready) return;
    let cancelled = false;
    const commit = () => {
      if (cancelled) return;
      const result = savePlanCompared(window.localStorage, planRaw.current, plan);
      setPlanSaveFailed(!result.ok);
      if (result.ok) { planRaw.current = result.raw; setPlanConflict(""); }
      else setPlanConflict(result.reason);
    };
    if (navigator.locks?.request) void navigator.locks.request("fr255-strength-plan-v3", commit);
    else { setPlanSaveFailed(true); setPlanConflict("浏览器不支持课表写入锁，暂不保存。草稿仍在，请换支持 Web Locks 的浏览器。"); }
    return () => { cancelled = true; };
  }, [plan, ready]);

  useEffect(() => {
    const sync = () => setOffline(!navigator.onLine);
    sync();
    window.addEventListener("online", sync);
    window.addEventListener("offline", sync);
    let registration: ServiceWorkerRegistration | null = null;
    let stopped = false;
    let prefetchInFlight: Promise<void> | null = null;
    const prefetch = () => {
      if (prefetchInFlight) return prefetchInFlight;
      const urls = offlinePrefetchUrls(location.origin,
        [...document.querySelectorAll("script[src], link[href]")]
          .map((node) => ("src" in node && typeof node.src === "string" && node.src ? node.src : node.getAttribute("href")) || ""),
        performance.getEntriesByType("resource").map(entry => entry.name),
      );
      prefetchInFlight = Promise.all(urls.map((href) => fetch(href, {
        cache: "reload",
        ...(new URL(href, location.origin).pathname === "/" ? { headers: { accept: "text/html", "x-fangkun-shell-prefetch": "1" } } : {}),
      }).catch(() => undefined))).then(async () => {
        const critical = urls.filter(href => {const path = new URL(href).pathname; return path === "/" || path.startsWith("/assets/") && /\.(?:m?js|css)$/.test(path)});
        const cached = await Promise.all(critical.map(href => caches.match(href, { ignoreVary: true })));
        if (!stopped) setOfflineShellState(cached.length > 0 && cached.every(response => response?.ok) ? "ready" : "unavailable");
      }).catch(() => {if (!stopped) setOfflineShellState("unavailable")}).finally(() => {prefetchInFlight = null});
      return prefetchInFlight;
    };
    const apply = () => {
      if (stopped || !("serviceWorker" in navigator) || !navigator.serviceWorker.controller) return;
      let trainingOpen = true;
      try { trainingOpen = trainingExecutionOpen(loadEvents()); } catch { trainingOpen = true; }
      const plan = serviceWorkerNavigationPlan({
        hasController: !!navigator.serviceWorker.controller,
        alreadyReloaded: sessionStorage.getItem("fr255-sw-reloaded") === "1",
        trainingOpen,
      });
      if (plan.reload) {
        sessionStorage.setItem("fr255-sw-reloaded", "1");
        location.reload();
        return;
      }
      if (plan.prefetch) void prefetch();
    };
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js", { updateViaCache: "none" }).then(async (next) => {
        registration = next;
        void next.update().catch(() => {});
        await navigator.serviceWorker.ready;
        apply();
      }).catch(() => {if (!stopped) setOfflineShellState("unavailable")});
      navigator.serviceWorker.addEventListener("controllerchange", apply);
    } else setOfflineShellState("unavailable");
    const update = () => { if (navigator.onLine) {void registration?.update(); apply()} };
    window.addEventListener("online", update);
    return () => {
      stopped = true;
      window.removeEventListener("online", sync);
      window.removeEventListener("offline", sync);
      window.removeEventListener("online", update);
      if ("serviceWorker" in navigator) navigator.serviceWorker.removeEventListener("controllerchange", apply);
    };
  }, []);

  const session = plan.sessions[Math.min(active, plan.sessions.length - 1)] ?? plan.sessions[0];
  const minutes = session ? estimateMinutes(session) : 0;
  const variant = homeVariant(preference);
  const trackHome = ready ? trackHomeView() : null;
  const quickAction = (q: QuickId | "more") => {
    if (q === "more") return setEditHome(true);
    if (q === "log") return setQuickOpen({ text: "", n: Date.now() });
    if (q === "weight") return setQuickOpen({ text: "体重 ", n: Date.now() });
    if (q === "import") { setBodyPane("device"); return setTab("body"); }
    if (q === "health") { setBodyPane("recovery"); return setTab("body"); }
    if (q === "coach") { setCoachLink("ask"); setCoachFocus(null); return setTab("coach"); }
    if (q === "diet") return setTab("diet");
    openTimer();
  };
  const openDetail = () => openTimer();
  const todayIso = (() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; })();
  useLocalReminders(todayIso);
  const liftLogged = Boolean(session && plan.cycle?.logs.some((log) => log.sessionId === session.id));
  const courseCount = (trackHome?.planId ? 1 : 0) + (session ? 1 : 0);
  // v83（P0-05）：今日各项状态来自统一读模型（V4 分项事实 + 日程上其他计划课），不再写死 0。
  const [todayCoord, setTodayCoord] = useState<{ parts: TodayPart[]; unplanned: number } | null>(null);
  const [hasImportedPlan, setHasImportedPlan] = useState(false);
  const [hasTrainingContent, setHasTrainingContent] = useState(false);
  useEffect(() => {
    const refresh = () => { try {
      const pd = planSrc === "400m-v4" ? planDay(todayIso) : undefined;
      const kind = pd ? dayKind(pd) : null;
      const activities = loadTrainingActivities(), entries = loadSchedule().entries, imported = hasActivePlan();
      setHasImportedPlan(imported);
      setHasTrainingContent(imported || activities.length > 0 || entries.some(e => e.status === 'planned' || e.status === 'done' || Boolean(e.actual)));
      setTodayCoord(todayCoordinationParts(activities, entries, todayIso, pd && kind !== 'rest' ? { run: hasRunPart(pd), lift: hasStrength(pd) && kind !== 'recovery' } : null));
    } catch { setTodayCoord(null); } };
    refresh(); const un = onAppEvent(refresh);
    const evs = [PLAN_CHANGED_EVT, 'fk-schedule-changed', 'fk-training-activities-changed', 'fk-plan400-changed', 'fk-plan400-components', 'fk-garmin-synced', 'storage'];
    for (const e of evs) window.addEventListener(e, refresh);
    return () => { un(); for (const e of evs) window.removeEventListener(e, refresh); };
  }, [todayIso, planSrc, tab]);
  const hasScheduledForPane = calendar.some(e => matchesScheduledPlanPane(e, hubPane === 'run' ? 'run' : 'strength'));
  const liftSummary = (session?.moves ?? []).slice(0, 4).map((move) => displayName(move)).join(" · ");
  const statusText = !ready ? "读取中" : trackHome?.openOccurrenceId ? "跑步进行中" : todayCoord?.parts.length ? todayPartsText(todayCoord.parts) : courseCount === 0 ? "暂无安排" : "待选择课程";
  const pageTitle = tab === "today" ? "今天" : inTraining ? "训练" : tab === "coach" ? "方坤" : tab === "diet" ? "饮食" : "健康";
  const phaseLabel = plan.cycle ? PHASES.find((item) => item.week === plan.cycle?.week)?.label ?? "" : "";
  const headerHint = tab === "today"
    ? (clockLabel ? `${clockLabel} · ${statusText}` : statusText)
    : tab === "plan"
      ? ""
      : tab === "log"
        ? ""
        : tab === "coach"
          ? "对话 · 学习 · 复盘"
          : "";
  const coachHint = !ready
    ? "正在读取本机记录。"
    : trackHome?.openOccurrenceId
      ? trackHome.progress
      : "";

  function choosePreference(next: SportGoalPreference) {
    if (typeof localStorage === "undefined" || !saveSportGoal(next, localStorage)) {
      setGoalSaveFailed(true);
      return;
    }
    setGoalSaveFailed(false);
    const loadedPreference = loadSportGoal();
    setPreference(loadedPreference);
    setSupportingGoals(loadSupportingGoals(localStorage, loadedPreference.primaryGoal));
  }

  const filtered = useMemo(() => {
    const q = query.trim();
    return CATALOG.filter((item) => {
      if (group !== "全部" && item.group !== group) return false;
      if (!q) return true;
      return item.name.includes(q) || item.group.includes(q);
    });
  }, [group, query]);

  function updateSession(patch: Partial<{ name: string; moves: Move[] }>) {
    if (!session) return;
    if (patch.moves) captureOriginalPlan(session);
    setPlan((current) => ({
      ...current,
      sessions: current.sessions.map((item) => (item.id === session.id ? { ...item, ...patch } : item)),
    }));
  }

  const demoDataHas = (id: string) => CATALOG.some(c => c.id === id);
  /** 动作库里的详情页：只有点“加入训练”才会打开训练编辑器（新建所选日期的训练，保存前可改）；浏览本身不写入。 */
  const libraryDemoAction = (id: string): DemoAction | undefined => {
    const action = LOCAL_MUSCLE_ACTIONS.find(a => a.catalogId === id);
    if (!action || !actionLibrary && !muscleOpen) return undefined;
    return { label: "加入训练", hint: `将新建 ${selectedDate} 的训练草稿，保存前可修改`, onClick: () => { setMuscleDemo(null); setTrainingEditor({ date: selectedDate, seedAction: action }); if (muscleOpen) setMuscleOpen(false); } };
  };
  const pickerDemoAction = (id: string): DemoAction | undefined => {
    if (!session) return undefined;
    if (session.moves.some(m => m.catalogId === id)) return { label: "已在本次训练", disabled: true, onClick: () => {} };
    const item = CATALOG.find(c => c.id === id);
    return { label: "选择此动作", hint: "加入后回到当前训练", onClick: () => { updateSession({ moves: [...session.moves, item ? moveFromCatalog(item) : customMove(id)] }); setPickerDemo(null); setPicker(false); setPickerMuscle(false); } };
  };

  function commitPlan(produce: (current: Plan) => Plan) {
    for (const item of plan.sessions) captureOriginalPlan(item);
    setPlan(produce(plan));
  }

  function updateMove(id: string, patch: Partial<Move>) {
    if (!session) return;
    updateSession({
      moves: session.moves.map((move) => (move.id === id ? { ...move, ...patch } : move)),
    });
    if (trainingDecision.current) {
      dispatchEvent("TRAINING_MODIFIED", { decisionId: trainingDecision.current, sessionId: session.id });
    }
  }

  function removeMove(id: string) {
    if (!session) return;
    updateSession({ moves: session.moves.filter((move) => move.id !== id) });
  }

  function shiftMove(id: string, dir: -1 | 1) {
    if (!session) return;
    const list = [...session.moves];
    const index = list.findIndex((move) => move.id === id);
    const next = index + dir;
    if (index < 0 || next < 0 || next >= list.length) return;
    const [item] = list.splice(index, 1);
    if (!item) return;
    list.splice(next, 0, item);
    updateSession({ moves: list });
  }

  function applyTemplate(id: string) {
    const template = TEMPLATES.find((item) => item.id === id);
    if (!template) return;
    commitPlan((current) => ({ ...ensureCycle(template.plan()), coachEditHistory: current.coachEditHistory, coachEditRevision: current.coachEditRevision }));
    setActive(0);
    setNotice(`已换成「${template.label}」，重量和次数都能改。`);
  }

  // FRAME-14: explicit user-controlled strength-session order change.
  // Keep session IDs, contents, historical logs and event identities unchanged.
  function reorderStrengthSession(direction: -1 | 1) {
    const target = active + direction;
    if (target < 0 || target >= plan.sessions.length) return;
    const currentSession = plan.sessions[active];
    const otherSession = plan.sessions[target];
    if (!currentSession || !otherSession) return;
    const accepted = window.confirm(
      `确认将「${currentSession.name}」与「${otherSession.name}」交换本周期显示顺序？\n\n这仅调整力量课表的排列，不代表已执行，也不等于方坤确认恢复或负荷安全。请检查高强度跑步、下肢力量、疼痛和比赛安排。已有训练记录保留原课程编号。`,
    );
    if (!accepted) return;
    setPlan((current) => {
      const sessions = [...current.sessions];
      const currentIndex = sessions.findIndex((item) => item.id === currentSession.id);
      const nextIndex = sessions.findIndex((item) => item.id === otherSession.id);
      if (currentIndex < 0 || nextIndex < 0) return current;
      [sessions[currentIndex], sessions[nextIndex]] = [sessions[nextIndex]!, sessions[currentIndex]!];
      return { ...current, sessions };
    });
    setActive(target);
    setNotice(`已调整力量课程顺序：${currentSession.name}。保存状态请查看页面顶部提示；跑步计划与历史日志未改。`);
  }

  // Preview-only. The plan and its audit are written in one localStorage value.
  // All current UI plan writers use the same lock and reject stale plan versions.
  const onControlledStrengthEdit: CoachStrengthAction = async (action, proposal, consent) => {
    if (typeof navigator === "undefined" || !navigator.locks?.request) return {ok:false,reason:"此浏览器不支持安全互斥锁，仅可查看提案，不能写入。"};
    return navigator.locks.request(PLAN_KEY, async () => {
      try {
        const raw = localStorage.getItem("fr255-strength-plan-v3");
        if (!raw || raw !== JSON.stringify(plan)) return {ok:false,reason:"本机计划已变化，拒绝覆盖；请刷新并重新生成提案。"};
        if (action === "APPLY" && (!proposal || raw !== proposal.expectedPlanRaw)) return {ok:false,reason:"提案已过期，不能写入。"};
        const today = new Date().toDateString();
        const startedToday = loadEvents().some(e => e.event_type === "TRAINING_STARTED" && new Date(e.timestamp).toDateString() === today &&
          e.payload && typeof e.payload === "object" && (e.payload as Record<string,unknown>).sessionId === (action === "APPLY" ? proposal?.sessionId : plan.coachEditHistory?.at(-1)?.sessionId));
        const recentPain = loadEvents().some(e => e.event_type === "PAIN_RECORDED" && Number.isFinite(Date.parse(e.timestamp)) &&
          Date.now() - Date.parse(e.timestamp) >= 0 && Date.now() - Date.parse(e.timestamp) <= 14 * 86400_000);
        const control: StrengthControl = {previewUnlocked:consent.previewUnlocked,athleteConfirmed:consent.athleteConfirmed,
          confirmedProposalId:consent.confirmedProposalId,hasTrainingStartedToday:startedToday || trainingExecutionOpen(loadEvents()),
          unresolvedPain:!consent.noCurrentPain || recentPain,timestamp:new Date().toISOString()};
        const result = action === "APPLY" ? applyStrengthReduction(plan,proposal!,control) : rollbackStrengthReduction(plan,control);
        if (!result.ok) return {ok:false,reason:result.reason};
        // Same-key plan+audit update: a failed write leaves both untouched.
        const saved = commitControlledStrengthPlan(localStorage, raw, result.plan);
        if (!saved.ok) return saved;
        planRaw.current=JSON.stringify(result.plan);
        setPlan(result.plan);
        return {ok:true,reason:result.reason};
      } catch {return {ok:false,reason:"无法读取或写入本机计划，已拒绝修改。"};}
    });
  };

  function addSession() {
    const next = { id: uid(), name: `第 ${plan.sessions.length + 1} 节`, moves: [] as Move[] };
    setPlan((current) => ({ ...current, sessions: [...current.sessions, next] }));
    setActive(plan.sessions.length);
    setPicker(true);
  }



  return (
    <div className={"app-wallpaper product-ui fk-identity bg-bg text-fg " + (tab === "coach" ? "fk-coach-shell flex h-dvh flex-col overflow-hidden" : "min-h-dvh")} data-testid="training-app" data-ready={ready} data-offline-ready={offlineShellState === "ready"} data-candidate-version="FK-UI-R1-20261021" data-wallpaper={wallpaper} data-fk-theme={characterTheme} data-theme={displayMode === "system" ? (systemDark ? "dark" : "light") : displayMode}>
      <header className={"ui03-header fk-page-header px-4 pt-1 pb-1" + (tab === "coach" ? " fk-coach-head" : "")}>
        <div className="ui03-header-inner fk-page mx-auto flex max-w-3xl items-center justify-between gap-3">
          <div className="min-w-0">
            {tab === "today" ? <><div className="fk-brand-lockup fk-mobile-only"><h1>FANGKUN</h1><span>方坤</span></div><h1 className="ui03-title fk-desk-only">今天</h1></> : <>
            <h1 className="ui03-title flex items-center gap-2 text-[1.55rem] font-bold leading-tight tracking-tight">{characterTheme !== "classic" && tab !== "coach" ? <img className="fk-coach-theme-avatar" src={getCharacterTheme(characterTheme)?.avatar} alt="" aria-hidden="true" /> : null}{pageTitle}</h1>
            {tab === "coach" || !headerHint ? null : <p className="ui03-subtitle truncate text-xs text-muted">{headerHint}</p>}</>}
          </div>
          <div className="flex shrink-0 items-center gap-2">
          {inTraining ? <button type="button" onClick={()=>setTrainingImportOpen(true)} className="min-h-11 shrink-0 rounded-full border border-line px-3 text-sm">补录实际训练</button> : null}
          {tab === "today" ? <button type="button" aria-label="记一笔" onClick={() => window.dispatchEvent(new Event("fk-open-quicklog"))} className="flex min-h-11 shrink-0 items-center gap-1 rounded-full border border-line px-3 text-sm font-bold text-accent"><Plus className="size-4" />记一笔</button> : null}
          {tab === "coach" ? <button type="button" onClick={() => setTab(prevTab.current)} className="grid size-11 shrink-0 place-items-center rounded-xl border border-line" aria-label="关闭方坤"><X className="size-5" /></button> : null}
          <button type="button" onClick={() => { menuScrollTop.current = 0; setSettingsPaneRaw("menu"); setSettingsOpen(true); }} className="ui03-settings grid size-11 shrink-0 place-items-center rounded-full bg-surface shadow-sm" aria-label="个人与数据"><Settings className="size-5" /></button></div>
        </div>
      </header>
      {offline ? <p className="fk-page mx-auto max-w-3xl px-4 pb-2 text-sm text-muted">当前没有网络。已缓存页面和本机记录可继续使用；方坤本地问答仍可用。</p> : null}
      {!offline && offlineShellState !== "ready" ? <p role="status" className="fk-page mx-auto max-w-3xl px-4 pb-2 text-xs text-muted">{offlineShellState === "preparing" ? "离线功能准备中…" : "离线功能暂不可用"}</p> : null}
      {planSaveFailed ? <div className="fk-page mx-auto flex max-w-3xl flex-wrap items-center gap-2 px-4 pb-2 text-sm">
        <p>{planConflict || PLAN_SAVE_FAIL}</p>
        <button type="button" className="min-h-11 rounded-card border border-line px-3 font-bold" onClick={() => { if (navigator.locks?.request) void navigator.locks.request(PLAN_KEY, () => { const result = savePlanCompared(localStorage, planRaw.current, plan); if(result.ok){planRaw.current=result.raw;setPlanSaveFailed(false);setPlanConflict("");}else setPlanConflict(result.reason); }); }}>再存一次</button>
        <button type="button" className="min-h-11 rounded-card border border-line px-3 font-bold" onClick={() => { setSettingsPaneRaw("backup"); setSettingsOpen(true); }}>下载备份</button>
      </div> : null}

      {inTraining ? <div className="fk-training-hub fk-page mx-auto max-w-3xl px-4">
        <nav className="fk-training-tabs" aria-label="训练视图">
          {([['plan', '计划'], ['log', '记录'], ['courses', '课程']] as const).map(([id, label]) => <button key={id} type="button" aria-current={tab === id ? "page" : undefined} onClick={() => setTab(id)}>{label}</button>)}
        </nav>
        {tab !== "log" ? <div className="fk-training-toolbar">
          <div className="flex gap-1" role="group" aria-label="运动类型">
            {([['run', '跑步', Footprints], ['lift', '力量', Dumbbell]] as const).map(([id, label, Icon]) => <button key={id} type="button" aria-pressed={hubPane === id} onClick={() => setHubPane(id)} className="flex min-h-11 items-center gap-1.5 rounded-xl px-3 font-bold"><Icon className="size-4" />{label}</button>)}
          </div>
          {tab === "plan" ? <button type="button" className="fk-primary flex items-center justify-center gap-1 px-4" onClick={() => setTrainingEditor({ date: selectedDate, initialType: hubPane === 'run' ? 'run' : 'strength' })}><Plus className="size-4" />添加训练</button> : null}
        </div> : null}
      </div> : null}
      <main className={"ui03-main fk-page mx-auto max-w-3xl px-3 pt-2 pb-nav" + (tab === "plan" || tab === "courses" ? " fk-main-train" : "") + (tab === "today" || tab === "plan" || tab === "courses" ? "" : " hidden")}>
        {tab === "today" ? (
          <div className="fk-today-grid">
          <div className="fk-today-main flex flex-col">
            {/* R4: hero intro removed to keep 今日 short; status lives in the strip below. */}

            <div className="fk-today-date"><span className="fk-date-day">{todayIso.slice(8, 10)}</span><div className="fk-date-context"><b>{Number(todayIso.slice(5, 7))}月 · 周{"日一二三四五六"[new Date(todayIso + "T12:00:00").getDay()]}</b></div></div>{planSrc === "400m-v4" ? <Plan400TodayCard today={todayIso} onReview={() => setTab("log")} /> : null}<HomeHeader today={todayIso} revision={homeRev} trainingStarted={hasTrainingContent} onRecovery={() => { setBodyPane("recovery"); setTab("body"); }} onOverride={(o) => setDayOverride(o)} layout={homeLayout} onEdit={() => setEditHome(true)} onQuick={quickAction} />
            <div style={{ order: homeLayout.order.indexOf("week") }}><TodayBoard v4={planSrc === "400m-v4"} revision={homeRev} override={dayOverride} band={bandOn} plan={plan} runPlans={ready ? listTrackPlans() : []} today={todayIso} selectedDate={selectedDate} onDateChange={setSelectedDate} onExecute={openScheduled} onEdit={editScheduled}
              gettingStarted={!hasTrainingContent} onImportPlan={() => setPlanImportOpen(true)} onBrowseCourses={() => { setHubPane('lift'); setTab('courses'); }}
              onOpenRun={(planId) => { if (!workspaceOpen) setCourseChoice(`run:${planId}`); openDetail(); }}
              onOpenLift={(sessionId) => { if (!workspaceOpen) { setCourseChoice(`lift:${sessionId}`); const i = plan.sessions.findIndex((x) => x.id === sessionId); if (i >= 0) setActive(i); } openDetail(); }}
              onFood={() => { setTab("diet"); }}
              onAskCoach={() => { setCoachLink("ask"); setCoachFocus(null); setTab("coach"); }} /></div>
            {/* Coach suggestions waiting for confirmation; shown only when there is one. */}
            <div style={{ order: homeLayout.order.indexOf("week") }} className="mb-3"><CoachSuggestionsPanel compact /></div>
            {hasTrainingContent ? <section id="detail-record" aria-label="本日训练执行入口" style={{ order: homeLayout.order.indexOf("detail") }} className="mb-3 px-1">
              <button type="button" className="flex min-h-12 w-full items-center justify-between rounded-xl border border-line px-4 text-left text-sm" onClick={openTimer}><span className="font-bold">计时与逐组记录</span><span aria-hidden="true" className="text-muted">›</span></button>
            </section> : null}
            <div style={{ order: 100 }} className="h-20" aria-hidden="true" />
          </div>
          {/* Desktop-only rail: shortcuts into existing flows; hidden below 1024px. */}
          <aside className="fk-today-rail" aria-label="快捷操作">
            <section className="home-card fk-rail-card">
              <h2 className="fk-rail-title">快捷操作</h2>
              <div className="fk-rail-actions">
                <button type="button" onClick={() => window.dispatchEvent(new Event("fk-open-quicklog"))}><Plus className="size-5" aria-hidden="true" /><span>记一笔<small>快速记录今天的训练</small></span></button>
                <button type="button" onClick={() => setTrainingEditor({ date: selectedDate, initialType: "strength" })}><Dumbbell className="size-5" aria-hidden="true" /><span>添加训练<small>安排到所选日期</small></span></button>
                <button type="button" onClick={() => { setTab("diet"); setDietSheet(true); setTimeout(() => document.getElementById("quick-food")?.scrollIntoView(), 50); }}><Utensils className="size-5" aria-hidden="true" /><span>记录饮食<small>餐次与营养</small></span></button>
                <button type="button" onClick={() => { setBodyPane("recovery"); setTab("body"); }}><Scale className="size-5" aria-hidden="true" /><span>查看恢复<small>睡眠、心率与疲劳</small></span></button>
                <button type="button" onClick={() => setPlanImportOpen(true)}><ClipboardList className="size-5" aria-hidden="true" /><span>导入计划<small>课表或备份文件</small></span></button>
              </div>
            </section>
            <section className="home-card fk-rail-card fk-rail-coach">
              <h2 className="fk-rail-title">问方坤</h2>
              <p>说说你的目标，或选一节训练一起看。方坤会先核对事实，再解释与建议。</p>
              <button type="button" className="fk-primary" onClick={() => { prevTab.current = tab; setCoachLink("ask"); setCoachFocus(null); setTab("coach"); }}><MessageCircle className="size-4" aria-hidden="true" />开始对话</button>
            </section>
          </aside>
          </div>
        ) : null}
        {workspaceMounted ? <section hidden={!workspaceOpen||tab!=="today"} aria-label="训练工作区" className="mb-4 space-y-3 rounded-card border border-line bg-surface p-4">
          <div className="flex items-center justify-between gap-2"><h2 className="font-bold">当前课程 · {courseChoice.startsWith("run:") ? courseChoice.slice(4) : session?.name}</h2><button type="button" className="min-h-11 text-sm" onClick={()=>{if(trainingDecision.current){setNotice("请先在执行页暂停或结束当前力量课，再选择其他课程。");return;}setWorkspaceOpen(false);}}>返回课程选择</button></div>
          {courseChoice.startsWith("run:") ? <TrackSessionPanel selectedPlanId={courseChoice.slice(4)} onLog={()=>setTab("log")} /> : session ? <>
            <TrainingDecisionCard key={session.id} plan={plan} session={session} onApply={next=>updateSession(next)} onLive={id=>{trainingDecision.current=id;}} />
            <details className="rounded-xl border border-line p-3"><summary className="min-h-11 cursor-pointer font-bold">已保存的课程安排</summary><SessionOverview name={session.name} focus={session.focus} moves={session.moves} minutes={minutes} onEdit={()=>{setEditorOpen(true);setPlanMore(true);setHubPane("lift");setTab("courses");}} /></details>
          </> : <p>选定课程已不存在，请重新选择。</p>}
        </section> : null}
        {tab === "plan" && hubPane === "run" && planSrc === "400m-v4" && (hasImportedPlan || !hasScheduledForPane) ? <Plan400Cycle today={todayIso} sourceSlot={<PlanSourceCard active={planSrc} onChange={setPlanSrcSaved} onGenerate={() => { setPlanSrcSaved("generated"); setCoachLink("ask"); setCoachFocus(null); setTab("coach"); }} />} /> : null}
        {tab === "plan" && hubPane === "run" && planSrc !== "400m-v4" ? (hasImportedPlan ? <PlanSourceCard active={planSrc} onChange={setPlanSrcSaved} onGenerate={() => { setPlanSrcSaved("generated"); setCoachLink("ask"); setCoachFocus(null); setTab("coach"); }} /> : !hasScheduledForPane ? <NoPlanCard onImported={() => setPlanSrcSaved('400m-v4')} sourceSlot={<PlanSourceCard active={planSrc} onChange={setPlanSrcSaved} onGenerate={() => { setPlanSrcSaved("generated"); setCoachLink("ask"); setCoachFocus(null); setTab("coach"); }} />} /> : null) : null}
        {tab === "plan" && hubPane === "lift" && planSrc === "400m-v4" ? <Plan400Cycle today={todayIso} lens="lift" /> : null}
        {tab === "plan" && hubPane === "lift" && !hasImportedPlan && !hasScheduledForPane ? <NoPlanCard onImported={() => setPlanSrcSaved('400m-v4')} /> : null}
        {tab === "plan" && hubPane === "lift" && hasImportedPlan && planSrc !== "400m-v4" ? <PlanSourceCard active={planSrc} onChange={setPlanSrcSaved} onGenerate={() => { setPlanSrcSaved('generated'); setCoachLink('ask'); setCoachFocus(null); setTab('coach'); }} /> : null}
        {tab === "plan" && hasScheduledForPane ? <button type="button" data-testid="plan-reorder" className="mb-3 min-h-12 w-full rounded-xl border border-line text-sm font-bold text-accent" onClick={()=>setCourseDatesOpen(true)}>移动或交换训练</button> : null}
        {tab === "plan" && hasScheduledForPane ? <TempTrainingList today={todayIso} entries={calendar} modality={hubPane === "run" ? "run" : "strength"} title={hubPane === "run" ? "自建跑步" : "自建力量"} addLabel="查看今天" onAdd={() => setTab("today")} onOpen={openScheduled} empty="还没有训练安排。" /> : null}
        {tab === 'plan' && hasScheduledForPane && !hasImportedPlan ? <button type="button" className="mb-3 min-h-12 w-full rounded-xl border border-line text-sm" onClick={() => setPlanImportOpen(true)}>导入计划或备份</button> : null}
        {tab === "courses" && hubPane === "lift" ? <>
          <section className="fk-course-card home-card mb-4 p-4" aria-label="力量动作">
            <div className="flex items-center justify-between gap-3"><h2 className="text-lg font-bold">力量动作</h2><button type="button" className="min-h-11 text-sm font-bold text-accent" onClick={() => setActionLibrary(true)}>全部动作 ›</button></div>
            <button type="button" className="mt-2 flex min-h-16 w-full items-center justify-between border-t border-line py-3 text-left font-bold" onClick={() => setTrainingEditor({ date: selectedDate, initialType: "strength", openMuscleInitially: true })}><span className="flex items-center gap-3"><Dumbbell className="size-5 text-accent" />按部位选动作</span><span aria-hidden="true">›</span></button>
          </section>
          <section className="fk-course-card home-card mb-4 p-4" aria-label="力量课程库">
            <div className="flex items-center justify-between gap-3"><h2 className="text-lg font-bold">力量课程</h2><button type="button" className="min-h-11 text-sm font-bold text-accent" onClick={() => setBuilderOpen(true)}>组合一课</button></div>
            {plan.sessions.map((s, i) => <div key={s.id} className="fk-course-row flex flex-wrap items-center justify-between gap-2 border-t border-line py-4">
              <div className="min-w-0 flex-1"><h3 className="font-bold">{s.name}</h3><p className="mt-1 text-sm text-muted">{s.moves.length} 个动作 · 约 {estimateMinutes(s)} 分钟</p></div>
              <div className="flex shrink-0 gap-1">
                <button type="button" className="min-h-11 rounded-xl px-3 text-sm" onClick={() => { setActive(i); setEditorOpen(true); setPlanMore(true); setTimeout(() => document.getElementById("session-editor")?.scrollIntoView({ block: "start", behavior: "smooth" }), 60); }}>编辑</button>
                <button type="button" className="min-h-11 rounded-xl border border-line px-3 text-sm font-bold text-accent" onClick={() => setTrainingEditor({ date: selectedDate, template: templateEntry(s.id) })}>安排训练</button>
              </div>
            </div>)}
            {plan.sessions.length === 0 ? <p className="py-4 text-sm text-muted">组合动作，保存你的第一节课。</p> : null}
          </section>
        </> : null}
        {tab === "courses" && hubPane === "run" ? <>
          <section className="fk-course-card home-card mb-4 p-4" aria-label="跑步课程库"><h2 className="text-lg font-bold">我的跑步课</h2>
            {ready && listTrackPlans().length ? listTrackPlans().map(p => <div key={p.planId} className="fk-course-row border-t border-line py-4"><p className="font-bold">{describeTrackPlan(p)}</p><button type="button" className="mt-2 min-h-11 rounded-xl border border-line px-3 text-sm font-bold text-accent" onClick={() => setTrainingEditor({ date: selectedDate, template: runEntry(p, selectedDate, "custom"), initialType: "run" })}>安排训练</button></div>) : <p className="py-4 text-sm text-muted">还没有保存的跑步课。</p>}
          </section>
          <section className="fk-course-card home-card mb-4 p-4" aria-label="跑步技术"><button type="button" className="flex min-h-12 w-full items-center justify-between text-left font-bold" onClick={() => setTechniqueLibrary(true)}><span className="flex items-center gap-3"><Footprints className="size-5 text-accent" />跑步技术动作库</span><span aria-hidden="true">›</span></button></section>
        </> : null}
        {tab === "courses" && hubPane === "lift" ? (
          <details className="home-card mb-3 px-3 py-3" aria-label="力量周期工具"><summary className="min-h-12 cursor-pointer font-bold">课程周期</summary>
            <div className="flex items-center justify-between gap-2 px-1">
              <h2 className="font-bold">课程周期</h2>
              <span className="text-xs text-muted">{plan.cycle ? `3 周训练 + 调整周` : "周期未就绪"}</span>
            </div>
            <div className="mt-3 grid grid-cols-4 gap-1" role="group" aria-label="训练周期周次">
              {PHASES.map((phase) => {
                const current = phase.week === (plan.cycle?.week ?? 1);
                return <button key={phase.week} type="button" aria-pressed={current} onClick={() => setWeekPeek(current ? null : phase.week)} className={"min-h-10 rounded-full text-xs font-bold " + (current ? "bg-surface-2 text-fg" : weekPeek === phase.week ? "text-accent" : "text-muted")}>第{["一", "二", "三", "四"][phase.week - 1]}周</button>;
              })}
            </div>
            {weekPeek && weekPeek !== plan.cycle?.week ? <p className="mt-2 px-1 text-xs text-muted">第 {weekPeek} 周是「{PHASES.find((item) => item.week === weekPeek)?.label}」。下面仍是当前已保存的课表，不会换成示例课。</p> : null}
            {/* v83（P1-03）：课程清单只在上方“已保存的力量课程”出现一次（编辑/加入训练都在那里）；跑步课在“跑步”视图 */}
          </details>
        ) : null}
        {tab === "courses" && hubPane === "lift" ? <details className="home-card mt-3 px-4 py-2" open={planMore} onToggle={(event) => setPlanMore(event.currentTarget.open)}>
          <summary className="min-h-12 cursor-pointer text-sm font-bold">管理课程</summary>
        {tab === "courses" && hubPane === "lift" && showPlanTools && plan.sessions.length > 1 ? (
          <nav aria-label="选择要查看的训练课" className="mb-4 rounded-card border border-line bg-surface p-3">
            <p className="mb-2 text-xs font-bold text-muted">查看本周期其他训练课 · 共 {plan.sessions.length} 节</p>
            <div className="flex gap-2 overflow-x-auto pb-1" role="group" aria-label="训练课列表">
              {plan.sessions.map((item, index) => (
                <button key={item.id} type="button" aria-pressed={index === active}
                  onClick={() => setActive(index)}
                  className={"min-h-11 shrink-0 rounded-card border px-3 text-sm font-bold " + (index === active ? "border-accent bg-accent text-accent-fg" : "border-line bg-bg text-fg")}>
                  第 {index + 1} 节 · {item.name}
                  {plan.cycle?.logs.some((log) => log.sessionId === item.id) ? " · 已记" : ""}
                </button>
              ))}
            </div>
            
            <div className="mt-3 rounded-card border border-line p-3">
              <p className="text-sm font-bold">手动调整本周期力量课程顺序</p>
              <p className="mt-1 text-xs text-muted">当前：第 {active + 1} 节 · {session?.name}。调整前会确认；只交换力量课程排列，不更改跑步计划、不自动判断恢复安全、不把课程记为完成。</p>
              <div className="mt-2 flex flex-wrap gap-2">
                <button type="button" disabled={active === 0} onClick={() => reorderStrengthSession(-1)} className="min-h-11 rounded-card border border-line px-4 text-sm font-bold disabled:opacity-40">向前调整一节</button>
                <button type="button" disabled={active >= plan.sessions.length - 1} onClick={() => reorderStrengthSession(1)} className="min-h-11 rounded-card border border-line px-4 text-sm font-bold disabled:opacity-40">向后调整一节</button>
              </div>
              
            </div>
          </nav>
        ) : null}
        {tab === "courses" && hubPane === "lift" ? <section>
          <button type="button" aria-expanded={showPlanTools} onClick={() => setShowPlanTools((current) => !current)} className="flex min-h-11 w-full items-center justify-between rounded-card border border-line bg-surface px-4 text-left text-sm font-bold">
            训练模板与周期管理 {showPlanTools ? <ChevronUp className="size-4" /> : <ChevronDown className="size-4" />}
          </button>
          {showPlanTools ? <>
          <h2 className="mt-3 text-sm font-medium text-muted">选一套再改</h2>
          <div className="mt-2 flex gap-2 overflow-x-auto pb-1">
            {TEMPLATES.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => applyTemplate(item.id)}
                className={"min-h-11 shrink-0 rounded-full border px-4 text-left " + (plan.kind === item.id ? "border-accent bg-surface" : "border-line bg-surface")}
              >
                <span className="block text-sm font-bold">{item.label}</span>
                <span className="block text-xs text-muted">{item.hint}</span>
              </button>
            ))}
            <button
              type="button"
              onClick={() => {
                commitPlan(() => ensureCycle(blankPlan()));
                setActive(0);
                setNotice("从空白课开始。");
              }}
              className="min-h-11 shrink-0 rounded-full border border-line px-4 text-sm font-bold"
            >
              自己排
            </button>
          </div>
          {profileFilled(profile) && plan.sessions.length > profile.days ? (
            <p className="mt-2 text-sm text-muted">你填了一周练 {profile.days} 次，这套有 {plan.sessions.length} 节。多出来的记成「这周没练」就行。</p>
          ) : null}
          <CycleCard
            plan={plan}
            onAdvance={() => {
              if (!weekReady(plan)) {
                setNotice("每节都记下感觉，才能生成下一周。没练的选「这周没练」。");
                return;
              }
              commitPlan((current) => advanceCycle(current).plan);
              setActive(0);
              setNotice("下一周已经按这周的反馈改好了。");
            }}
          />
          </> : null}
        </section> : null}
        {tab === "courses" && hubPane === "lift" ? <details className="mt-3 rounded-card border border-line bg-surface p-3">
          <summary className="min-h-11 cursor-pointer py-2 text-sm font-bold">实验功能 · 周期计划候选</summary>
          
          <button
            type="button"
            onClick={() => setCoachPlanOpen(true)}
            className="mt-3 flex min-h-14 w-full items-center justify-between rounded-card border border-line bg-bg px-4 text-left"
          >
            <span>
              <span className="block font-bold">查看实验候选</span>
              <span className="block text-sm text-muted">不会写进今天的课表</span>
            </span>
            <ChevronUp className="size-5 rotate-45 text-accent" />
          </button>
        </details> : null}


        {tab === "courses" && hubPane === "lift" ? <details id="session-editor" open={editorOpen} onToggle={(event) => setEditorOpen(event.currentTarget.open)} className="mt-5 rounded-card border border-line bg-surface p-3">
          <summary className="cursor-pointer text-sm font-bold">调整这节课</summary>
          <div className="mt-3 flex items-center gap-2 overflow-x-auto">
            {plan.sessions.map((item, index) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setActive(index)}
                className={"min-h-11 shrink-0 rounded-full px-4 text-sm font-bold " + (index === active ? "bg-accent text-accent-fg" : "bg-surface text-fg")}
              >
                {item.name}
                {plan.cycle?.logs.some((log) => log.sessionId === item.id) ? <span className="ml-1 text-xs font-medium">已记</span> : null}
              </button>
            ))}
            <button type="button" onClick={addSession} className="grid size-11 shrink-0 place-items-center rounded-full border border-line" aria-label="加一节课">
              <Plus className="size-5" />
            </button>
          </div>

          {session ? (
            <div className="mt-4">
              <label className="block text-sm text-muted" htmlFor="session-name">
                这节课的名字
              </label>
              <input
                id="session-name"
                value={session.name}
                maxLength={24}
                suppressHydrationWarning
                onChange={(event) => updateSession({ name: event.target.value })}
                className="mt-1 h-12 w-full rounded-card border border-line bg-surface px-3 text-lg font-bold outline-none"
              />
              <p className="mt-2 text-sm text-muted">
                大约 {minutes} 分钟 · {session.moves.length} 个动作
              </p>
              {session.focus ? <p className="mt-1 text-sm text-fg">{session.focus}</p> : null}
              {profile && minutes > profile.minutes + 5 ? (
                <p className="mt-1 text-sm text-warn">这节约 {minutes} 分钟，你填的晚上只有 {profile.minutes} 分钟。跟教练说「只有{profile.minutes}分钟」会帮你砍短。</p>
              ) : null}
              {profile && /膝/.test(profile.limit) && session.moves.some((move) => ["goblet", "bss", "step-up", "db-lunge"].includes(move.catalogId ?? "")) ? (
                <p className="mt-1 text-sm text-warn">你填过：{profile.limit}。这节有蹲，疼就停，或跟教练说膝盖不舒服。</p>
              ) : null}
              <ul className="mt-3 flex flex-col gap-3">
                {session.moves.map((move, index) => (
                  <li key={move.id} className="rounded-card border border-line bg-surface p-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-xs text-muted">动作 {index + 1}</p>
                        <p className="text-base font-bold">{displayName(move)}</p>
                        <button type="button" onClick={() => setFormMove(move)} className="mt-1 text-sm font-bold text-accent">
                          怎么做
                        </button>
                      </div>
                      <div className="flex">
                        <IconButton label="上移" disabled={index === 0} onClick={() => shiftMove(move.id, -1)}>
                          <ChevronUp className="size-4" />
                        </IconButton>
                        <IconButton label="下移" disabled={index === session.moves.length - 1} onClick={() => shiftMove(move.id, 1)}>
                          <ChevronDown className="size-4" />
                        </IconButton>
                        <IconButton label="删除" onClick={() => removeMove(move.id)}>
                          <Trash2 className="size-4" />
                        </IconButton>
                      </div>
                    </div>
                    <div className="mt-3 grid grid-cols-2 gap-2">
                      <Stepper label="组数" value={move.sets} min={1} max={12} step={1} onChange={(sets) => updateMove(move.id, { sets })} />
                      <Stepper
                        label={move.mode === "seconds" ? "每组秒数" : "每组次数"}
                        value={move.amount}
                        min={1}
                        max={move.mode === "seconds" ? 300 : 50}
                        step={move.mode === "seconds" ? 5 : 1}
                        onChange={(amount) => updateMove(move.id, { amount })}
                      />
                      <Stepper label="组间休息" suffix="秒" value={move.restSec} min={0} max={300} step={15} onChange={(restSec) => updateMove(move.id, { restSec })} />
                      <Stepper label="重量" suffix="kg" value={move.weightKg} min={0} max={200} step={2.5} onChange={(weightKg) => updateMove(move.id, { weightKg })} />
                    </div>
                    <div className="mt-2 flex gap-2">
                      <Toggle pressed={move.mode === "reps"} onClick={() => updateMove(move.id, { mode: "reps", amount: move.mode === "reps" ? move.amount : 10 })}>
                        计次数
                      </Toggle>
                      <Toggle
                        pressed={move.mode === "seconds"}
                        onClick={() => updateMove(move.id, { mode: "seconds", amount: move.mode === "seconds" ? move.amount : 30 })}
                      >
                        倒计时
                      </Toggle>
                      {move.weightKg === 0 ? <span className="self-center text-xs text-muted">自重</span> : null}
                    </div>
                  </li>
                ))}
              </ul>

              {session.moves.length === 0 ? (
                <p className="mt-4 rounded-card border border-dashed border-line px-4 py-8 text-center text-sm text-muted">这节还是空的。加上第一个动作。</p>
              ) : null}
              <button
                type="button"
                onClick={() => {
                  setQuery("");
                  setPicker(true);
                }}
                className="mt-2 flex h-12 w-full items-center justify-center gap-2 rounded-card border border-line bg-surface-2 font-bold"
              >
                <Plus className="size-5" />
                添加动作
              </button>
            </div>
          ) : null}
        </details> : null}
        </details> : null}

        {notice ? <p className="mt-4 text-sm text-warn">{notice}</p> : null}
      </main>
      {tab === "log" ? <TrainingLogPage today={todayIso} plan={plan} onNavigate={(next) => setTab(next as typeof tab)} onAsk={(occurrenceId) => { setCoachLink(occurrenceId ? "bound" : "unbound"); setCoachFocus(occurrenceId); setTab("coach"); }} /> : null}
      <CoachWeeklyBootstrap ready={ready} />
      {tab === "coach" ? <CoachSheet embedded characterTheme={characterTheme} questionDraft={coachSeed?.text ?? null} questionContext={coachSeed?.chip ?? null} onQuestionDraftConsumed={() => setCoachSeed(null)} plan={plan} activeId={session?.id} focusOccurrenceId={coachFocus} link={coachLink} onControlledStrengthEdit={onControlledStrengthEdit} onClose={() => setTab("today")} onJump={() => { setBodyPane("recovery"); setTab("body"); }} onNavigate={(next) => { setTab(next); }}
        coordinationPanel={<CoachCoordinationHub input={{ loaded: ready && !!todayCoord, todayParts: todayCoord?.parts, todayUnplanned: todayCoord?.unplanned, strengthSessions: plan.sessions.length }} onNavigate={(next) => setTab(next)} />}
      /> : null}
      <div className={tab === "diet" ? "" : "hidden"}><div className="ui03-main fk-page fk-desk-diet mx-auto max-w-3xl px-4 pt-3 pb-nav"><HomeDashboard only="diet" onFood={() => { setDietSheet(true); setTimeout(() => document.getElementById("quick-food")?.scrollIntoView(), 50); }} onAdvice={() => setDietSheet(true)} onBody={() => { setBodyPane("trend"); setTab("body"); }} /></div>{dietSheet ? <div className="fixed inset-0 z-50 overflow-y-auto bg-bg pb-10" role="dialog" aria-label="饮食详情"><div className="sticky top-0 z-10 flex min-h-12 items-center justify-between border-b border-line bg-bg px-4 pb-1" style={{ paddingTop: "max(4px, env(safe-area-inset-top))" }}><b>饮食详情</b><button type="button" className="min-h-11 px-3" onClick={() => setDietSheet(false)}>关闭</button></div><div className="fk-detail"><DietPage active={tab === "diet"} profile={profile} onEditProfile={() => setProfileOpen(true)} /></div></div> : null}</div>
      <div className={tab === "body" ? "" : "hidden"}><div className="ui03-main fk-page fk-desk-body mx-auto max-w-3xl px-4 pt-3 pb-nav"><HomeDashboard only="body" onProfile={() => setProfileOpen(true)} onFood={() => setTab("diet")} onBody={() => setBodyPane("trend")} onCoach={(day) => { if (tab !== "coach") prevTab.current = tab; setCoachLink("ask"); setCoachFocus(null); setCoachSeed(day ? { text: `请结合我${Number(day.slice(5, 7))}月${Number(day.slice(8, 10))}日的恢复与健康记录，看看今天该怎么安排。`, chip: `健康 · ${Number(day.slice(5, 7))}月${Number(day.slice(8, 10))}日` } : null); setTab("coach"); }} slot={<BodyCenter compact active={tab === "body"} initialPane={bodyPane} profile={profile} onEdit={() => setProfileOpen(true)} onProfile={(next) => { saveProfile(next); setProfile(next); }} />} /></div>
      </div>
      <StandaloneWelcome suspended={settingsOpen || firstRun} />
      {settingsOpen ? (
        <div ref={settingsScroll} className="fixed inset-0 z-40 overflow-y-auto bg-bg" data-testid="settings-overlay" role="dialog" aria-modal="true" aria-label={settingsPane === "sync" ? "设备与数据同步" : "个人与设置"}>
        <div className="mx-auto max-w-3xl px-4 pb-nav">
          {/* R5: sticky header — title + close stay reachable below the iPhone notch while long panes scroll. */}
          <div data-testid="settings-header" className="sticky top-0 z-20 -mx-4 flex items-center justify-between border-b border-line bg-bg px-4 pb-2" style={{ paddingTop: "max(6px, env(safe-area-inset-top))" }}>
            <div className="fk-settings-heading">
              {settingsPane === "menu" ? null : <button type="button" className="fk-settings-back" aria-label="返回个人与设置" onClick={() => setSettingsPane("menu")}><ChevronLeft className="size-5" aria-hidden="true" /></button>}
              <h2 className="font-bold">{({ menu: "个人与设置", athlete: "运动员档案", goals: "训练目标与赛季计划", health: "健康与训练限制", sync: "设备与数据同步", import: "设备与数据同步", backup: "备份与恢复", coach: "教练与提醒", theme: "外观与显示", ai: "AI 服务与联网功能", privacy: "隐私与数据流向" } as Record<SettingsPane, string>)[settingsPane]}</h2>
            </div>
            <button type="button" onClick={() => setSettingsOpen(false)} className="grid size-11 place-items-center rounded-full bg-surface shadow-sm" aria-label="关闭设置"><X className="size-5" /></button>
          </div>
          {settingsPane === "menu" ? <SettingsMenu profile={profile} sportGoal={`${SPORTS.find((item) => item.id === preference.sport)?.label ?? "项目未选"} · ${GOALS.find((item) => item.id === preference.primaryGoal)?.label ?? "目标未选"}`} displayText={`${displayMode === "light" ? "浅色" : displayMode === "dark" ? "深色" : "跟随系统"} · 字体${fontScale === "standard" ? "标准" : fontScale === "large" ? "大" : "特大"} · ${getCharacterTheme(characterTheme)?.name ?? "经典"}`} onPane={setSettingsPane} onProfile={() => setProfileOpen(true)} /> : null}
          {settingsPane === "menu" ? <StorageHint /> : null}
          {settingsPane === "athlete" ? <><AthletePanel profile={profile} onEdit={() => setProfileOpen(true)} /><SettingsHub only={["p", "n"]} initialOpen="p" onProfile={() => setProfileOpen(true)} onDiet={() => { setSettingsOpen(false); setTab("diet"); }} onBackup={() => setSettingsPane("backup")} /></> : null}
          {settingsPane === "health" ? <><HealthPanel /><SettingsHub only={["h"]} initialOpen="h" onProfile={() => setProfileOpen(true)} onDiet={() => { setSettingsOpen(false); setTab("diet"); }} onBackup={() => setSettingsPane("backup")} /></> : null}
          {settingsPane === "sync" ? <DeviceSyncCenter today={todayIso} request={syncRequest} callback={syncCallback} onSaved={() => setHomeRev(v => v + 1)}><SettingsHub only={["d"]} onProfile={() => setProfileOpen(true)} onDiet={() => { setSettingsOpen(false); setTab("diet"); }} onBackup={() => setSettingsPane("backup")} /></DeviceSyncCenter> : null}
          {settingsPane === "coach" ? <SettingsHub only={["c", "r"]} initialOpen="c" onProfile={() => setProfileOpen(true)} onDiet={() => { setSettingsOpen(false); setTab("diet"); }} onBackup={() => setSettingsPane("backup")} /> : null}
          {settingsPane === "ai" ? <OnlineFeaturesSettings /> : null}
          {settingsPane === "privacy" ? <><PrivacyPanel /><SettingsHub only={["x"]} onProfile={() => setProfileOpen(true)} onDiet={() => { setSettingsOpen(false); setTab("diet"); }} onBackup={() => setSettingsPane("backup")} /></> : null}
          {settingsPane === "theme" ? <AppearanceSettings
            displayMode={displayMode} fontScale={fontScale} wallpaper={wallpaper} characterTheme={characterTheme}
            onDisplayMode={(id) => {
              if (writeDisplayMode(window.localStorage, id)) setDisplayMode(id);
              else setNotice("显示模式保存失败，其他记录未修改。");
            }}
            onFontScale={(id) => {
              if (writeFontScale(window.localStorage, id)) setFontScale(id);
              else setNotice("字体设置保存失败，训练数据未修改。");
            }}
            onWallpaper={(id) => {
              if (writeWallpaper(localStorage, id)) setWallpaper(id);
              else setNotice("壁纸设置未能保存，当前记录不会被修改。");
            }}
            onCharacterTheme={(id) => {
              if (writeCharacterTheme(localStorage, id)) { setCharacterTheme(id); window.dispatchEvent(new Event("fk-character-theme-change")); }
              else setNotice("角色主题保存失败，训练和历史数据未修改。");
            }}
          /> : null}
          {settingsPane === "theme" ? <SettingsHub only={["v"]} onProfile={() => setProfileOpen(true)} onDiet={() => { setSettingsOpen(false); setTab("diet"); }} onBackup={() => setSettingsPane("backup")} /> : null}
          {settingsPane === "goals" ? <section id="settings-goals" className="home-card mt-3 p-4 text-sm">
            <h2 className="font-bold">运动项目与目标</h2>
            
            <p className="mt-3 text-xs font-bold text-muted">运动项目</p>
            <div className="mt-2 flex flex-col gap-2">
              {SPORTS.map((item) => (
                <button key={item.id} type="button" aria-pressed={preference.sport === item.id} onClick={() => choosePreference({ ...preference, sport: item.id as SportId })} className={"min-h-11 rounded-card border px-3 text-left font-bold " + (preference.sport === item.id ? "border-accent bg-bg" : "border-line")}>{item.label}</button>
              ))}
            </div>
            <p className="mt-3 text-xs font-bold text-muted">主要目标</p>
            <div className="mt-2 flex flex-wrap gap-2">
              {GOALS.map((item) => (
                <button key={item.id} type="button" aria-pressed={preference.primaryGoal === item.id} aria-label={`主要目标 ${item.label}`} onClick={() => choosePreference({ ...preference, primaryGoal: item.id as GoalId, secondaryGoal: preference.secondaryGoal === item.id ? null : preference.secondaryGoal })} className={"min-h-11 rounded-full border px-3 font-bold " + (preference.primaryGoal === item.id ? "border-accent bg-bg" : "border-line")}>{item.label}</button>
              ))}
            </div>
            <p className="mt-3 text-xs font-bold text-muted">次要目标</p>
            <div className="mt-2 flex flex-wrap gap-2">
              <button type="button" aria-pressed={preference.secondaryGoal == null} onClick={() => choosePreference({ ...preference, secondaryGoal: null })} className={"min-h-11 rounded-full border px-3 font-bold " + (preference.secondaryGoal == null ? "border-accent bg-bg" : "border-line")}>无</button>
              {GOALS.filter((item) => item.id !== preference.primaryGoal).map((item) => (
                <button key={item.id} type="button" aria-pressed={preference.secondaryGoal === item.id} aria-label={`次要目标 ${item.label}`} onClick={() => choosePreference({ ...preference, secondaryGoal: item.id as GoalId })} className={"min-h-11 rounded-full border px-3 font-bold " + (preference.secondaryGoal === item.id ? "border-accent bg-bg" : "border-line")}>{item.label}</button>
              ))}
            </div>
            <div className="mt-4 border-t border-line pt-3">
              <p className="font-bold">其他并行目标（可多选）</p>
              
              <div className="mt-2 flex flex-wrap gap-2">
                {GOALS.filter((item) => item.id !== preference.primaryGoal).map((item) => {
                  const selected = supportingGoals.includes(item.id as GoalId)
                  return <button key={item.id} type="button" aria-pressed={selected} className={"min-h-11 rounded-full border px-3 font-bold " + (selected ? "border-accent bg-bg" : "border-line")} onClick={() => {
                    const next = selected ? supportingGoals.filter((id) => id !== item.id) : [...supportingGoals, item.id as GoalId]
                    if (saveSupportingGoals(localStorage, next, preference.primaryGoal)) setSupportingGoals(next)
                    else setNotice("并行目标保存失败，原有目标未改变。")
                  }}>{selected ? "✓ " : "+ "}{item.label}</button>
                })}
              </div>
            </div>
            {goalSaveFailed ? <p className="mt-2 text-warn">偏好没有写入本机，原来的记录还在。</p> : <p className="mt-2 text-xs text-muted">当前首页：{variant === "track" ? "田径" : variant === "fat-loss" ? "减脂" : variant === "muscle" ? "增肌 / 力量" : "综合体能"}。刷新后会记住这个选择。</p>}
          </section> : null}
          {settingsPane === "backup" ? <BackupCenter onNotice={setNotice} legacySlot={<div id="settings-backup" className="text-sm"><p className="mt-1 text-xs text-muted">版本 {TRIAL_VERSION}。新分块备份提供更完整的文本记录范围；这里保留旧格式兼容入口。</p>
            <button type="button" className="mt-3 h-12 w-full rounded-card border border-line font-bold" onClick={() => {
              const blob = new Blob([collectLocalBackup(localStorage)], { type: "application/json" })
              const url = URL.createObjectURL(blob)
              const link = document.createElement("a")
              link.href = url
              link.download = "running-strength-backup.json"
              link.click()
              URL.revokeObjectURL(url)
              setNotice("浏览器已开始下载训练记录备份（仅 fr255- 开头的数据，不含模型密钥）。请在“文件/下载”里确认。")
            }}>下载训练记录备份（旧格式）</button>
            <a className="mt-2 flex h-12 w-full items-center justify-center rounded-card border border-line font-bold" href="/running-strength-cn.zip" download="跑步力量-大陆静态版.zip">下载大陆静态网页包</a>
            <label className="mt-2 flex h-12 w-full items-center justify-center rounded-card border border-line font-bold">
              用旧格式文件恢复（训练记录备份）
              <input type="file" accept="application/json" className="sr-only" onChange={async (event) => {
                const file = event.target.files?.[0]
                event.target.value = ""
                if (!file) return
                try {
                  const result = await importVault(file)
                  setNotice(result.reason + (result.candidateId ? ` 待核副本编号：${result.candidateId}（可在备份中心下载）` : ''))
                } catch {
                  setNotice("待核副本未完成，当前记录未修改。请保留原始备份文件。")
                }
              }} />
            </label>
            <button type="button" className="mt-2 min-h-11 w-full rounded-card border border-line" onClick={exportFeedback}>导出反馈记录</button>
          </div>} /> : null}
          {notice ? <p className="mt-3 text-sm">{notice}</p> : null}
        </div>
        </div>
      ) : null}
      <Plan400DayHost today={todayIso} />
      <RunImportPrompt today={todayIso} />
      <QuickLog hideFab openWith={quickOpen} today={todayIso} onSaved={() => setHomeRev((v) => v + 1)} onFile={() => { setBodyPane("device"); setTab("body"); }} />
      {editHome ? <HomeEditor layout={homeLayout} onChange={setHomeLayout} onClose={() => setEditHome(false)} /> : null}
      {healthLink ? <HealthLinkSheet text={healthLink} onClose={() => { setHealthLink(null); setHomeRev((v) => v + 1); }} /> : null}
      {planImportOpen ? <AppSheet title="导入训练计划" label="导入训练计划" footer={null} onClose={() => setPlanImportOpen(false)}><PlanImportPanel onImported={() => { setPlanImportOpen(false); setPlanSrcSaved('400m-v4'); setTab('plan'); }} /></AppSheet> : null}
      {firstRun ? <Onboarding suspended={settingsOpen} today={todayIso} onDone={() => { setFirstRun(false); setHomeRev((v) => v + 1); }} /> : null}
      <ChromeMetrics />
      <FloatingPet theme={characterTheme} page={tab} onCoachTab={tab === "coach"} />
      <PetCaptureHost onCoach={id=>{setCoachFocus(id);setCoachLink(id?'bound':'ask');setTab('coach')}} />
      <button type="button" aria-label="打开快捷记录" className="fixed z-30 min-h-11 rounded-full border border-line bg-surface px-3 text-xs shadow-sm" style={{left:'calc(var(--fk-side-w, 0px) + 12px)',bottom:'calc(env(safe-area-inset-bottom, 0px) + 84px)'}} onClick={()=>openPetCapture()}>＋ 快捷记录</button>
      <nav className={"ui03-dock dock fixed inset-x-0 bottom-0 z-20" + (tab === "coach" ? " fk-dock-coach" : "")} aria-label="主导航">
        <div className="ui03-dock-inner mx-auto grid max-w-3xl grid-cols-5">
          <div className="fk-side-brand fk-desk-only" aria-hidden="true"><span className="fk-side-mark">坤</span><span><b>FANGKUN</b><small>方坤 · 训练教练</small></span></div>
          {(
            [
              ["today", "今天", House],
              ["plan", "训练", ClipboardList],
              ["coach", "方坤", MessageCircle],
              ["diet", "饮食", Utensils],
              ["body", "健康", Scale],
            ] as const
          ).map(([id, label, Icon]) => (
            <button
              key={id}
              type="button"
              onClick={() => { if (id === "coach" && tab !== "coach") { prevTab.current = tab; setCoachLink("ask"); setCoachFocus(null); } setTab(id); }}
              aria-label={`切换到${label}`}
              aria-current={(tab === id || (id === "plan" && inTraining)) ? "page" : undefined}
              className={"ui03-tab flex min-h-16 flex-col items-center justify-center gap-0.5 text-[11px] font-bold " + "" + ((tab === id || (id === "plan" && inTraining)) ? "ui03-tab-active text-accent" : "text-muted")}
            >
              <span className={"ui03-tab-icon grid h-8 min-w-12 place-items-center rounded-2xl " + ((tab === id || (id === "plan" && inTraining)) ? "stat-run" : "")}><Icon className="size-5" strokeWidth={(tab === id || (id === "plan" && inTraining)) ? 2.4 : 2} /></span>
              <span className="ui03-tab-label">{label}</span>
              {id === "coach" && suggestionCount ? <span className="fk-tab-badge" aria-label={`${suggestionCount} 条建议待确认`}>{suggestionCount}</span> : null}
            </button>
          ))}
          <button type="button" className="ui03-tab fk-side-settings fk-desk-only text-muted" onClick={() => { menuScrollTop.current = 0; setSettingsPaneRaw("menu"); setSettingsOpen(true); }} aria-label="个人与数据">
            <span className="ui03-tab-icon grid h-8 min-w-12 place-items-center"><Settings className="size-5" /></span>
            <span className="ui03-tab-label">设置</span>
          </button>
        </div>
      </nav>

      {picker ? (
        <Sheet title="选动作" onClose={() => setPicker(false)}>
          {/* v83（P2-01）：与“添加训练/组合一课”共用同一个 ActionPicker（搜索/分类/肌肉图三条路径，同一个“加入”） */}
          <ActionPicker selectedKeys={(session?.moves ?? []).map(m => m.catalogId ? `local:${m.catalogId}` : `extra:${displayName(m)}`)}
            onAdd={(entry) => { if (!session) return; const item = entry.catalogId ? CATALOG.find(c => c.id === entry.catalogId) : undefined; updateSession({ moves: [...session.moves, item ? moveFromCatalog(item) : customMove(entry.name)] }); setPicker(false); }}
            onPreview={(entry) => { if (entry.catalogId && demoDataHas(entry.catalogId)) setPickerDemo(entry.catalogId); else setNotice(`${entry.name} · ${entry.section} · ${entry.pattern}（加入后可在动作卡里看说明/动画）`); }}
            onMuscle={() => setPickerMuscle(true)} />
          {pickerMuscle ? <MuscleExplorerSheet onClose={() => setPickerMuscle(false)} onAdd={(action) => { if (!session) return; const item = action.catalogId ? CATALOG.find(c => c.id === action.catalogId) : undefined; updateSession({ moves: [...session.moves, item ? moveFromCatalog(item) : customMove(action.name)] }); setPickerMuscle(false); setPicker(false); }} /> : null}
        </Sheet>
      ) : null}

      {feedback && session ? (
        <Sheet title="训练反馈" onClose={() => setFeedback(false)}>
          <div className="rounded-card border border-line bg-surface-2 p-3">
            <p className="text-xs font-bold text-muted">正在记录</p>
            <p className="mt-1 text-base font-bold">{session.name}</p>
            
          </div>
          <fieldset className="mt-4">
            <legend className="text-sm font-bold">1. 这节练得怎么样？</legend>
            <div className="mt-2 grid grid-cols-2 gap-2">
              {FEELS.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  aria-pressed={feel === item.id}
                  onClick={() => setFeel(item.id)}
                  className={"min-h-16 rounded-card border px-3 py-2 text-left transition-colors " + (feel === item.id ? "border-accent bg-accent text-accent-fg" : "border-line bg-surface") + (item.id === "skip" ? " col-span-2" : "")}
                >
                  <span className="block font-bold">{item.label}</span>
                  <span className={"mt-0.5 block text-xs " + (feel === item.id ? "text-accent-fg" : "text-muted")}>{item.hint}</span>
                </button>
              ))}
            </div>
          </fieldset>
          {feel === "pain" ? (
            <fieldset className="mt-4 rounded-card border border-line p-3">
              <legend className="px-1 text-sm font-bold">2. 哪个动作不舒服？</legend>
              
              <div className="flex flex-wrap gap-2">
                {session.moves.map((move) => {
                  const on = painIds.includes(move.id);
                  return (
                    <button
                      key={move.id}
                      type="button"
                      aria-pressed={on}
                      onClick={() => setPainIds((current) => (current.includes(move.id) ? current.filter((id) => id !== move.id) : [...current, move.id]))}
                      className={"min-h-11 rounded-full border px-3 py-2 text-sm " + (on ? "border-accent bg-accent font-bold text-accent-fg" : "border-line bg-surface")}
                    >
                      {on ? "✓ " : ""}{displayName(move)}
                    </button>
                  );
                })}
              </div>
            </fieldset>
          ) : null}
          <details className="mt-4 rounded-card border border-line px-3">
            <summary className="flex min-h-12 cursor-pointer items-center text-sm font-bold">{feelNote ? "补充说明（已填写）" : "补充说明（可选）"}</summary>
            <label className="block pb-3 text-sm text-muted" htmlFor="feel-note">
              想记录疼痛位置、主观状态或训练感受，可以写在这里。
              <textarea
                id="feel-note"
                value={feelNote}
                maxLength={80}
                rows={2}
                onChange={(event) => setFeelNote(event.target.value)}
                placeholder="例如：左膝弯曲时不舒服"
                className="mt-2 w-full resize-y rounded-card border border-line bg-surface px-3 py-2 text-base text-fg outline-none"
              />
              <span className="mt-1 block text-right text-xs">{feelNote.length}/80</span>
            </label>
          </details>
          
          <button
            type="button"
            onClick={() => {
              setPlan(logSession(plan, session.id, feel, painIds, feelNote));
              const coachOk = saveCoach(absorbFeel(loadCoach(), session.name, feel, feelNote));
              setFeedback(false);
              const left = plan.sessions.filter((item) => item.id !== session.id && !plan.cycle?.logs.some((log) => log.sessionId === item.id)).length;
              setNotice(coachOk ? (left === 0 ? "记下了，教练也看到了。这周可以生成下一周。" : `记下了，教练也看到了。还差 ${left} 节。`) : COACH_SAVE_FAIL);
            }}
            className="mt-3 flex min-h-12 w-full items-center justify-center rounded-card bg-accent px-3 font-bold text-accent-fg"
          >
            {plan.cycle?.logs.some((log) => log.sessionId === session.id) ? "保存反馈修改" : "确认并保存反馈"}
          </button>
        </Sheet>
      ) : null}

      {builderOpen ? <Sheet title="组合课程草稿" onClose={()=>{if(!builderSaving.current)setBuilderOpen(false);}}><SessionBuilder onCancel={()=>{if(!builderSaving.current)setBuilderOpen(false);}} onConfirm={async draft=>{
        if(!navigator.locks?.request)return {ok:false,reason:"浏览器不支持写入锁，草稿保留。"};
        builderSaving.current=true;
        try { return await navigator.locks.request(PLAN_KEY,()=>{
          const result=appendSessionCompared(localStorage,planRaw.current,plan,draft);
          if(!result.ok)return result;
          planRaw.current=result.raw;setPlan(result.plan);setActive(result.plan.sessions.length-1);setBuilderOpen(false);setNotice(`已保存一节组合课：${draft.name}。尚未执行。`);return {ok:true};
        }); } finally {builderSaving.current=false;}
      }} /></Sheet> : null}
      {muscleOpen ? <MuscleExplorerSheet onClose={() => setMuscleOpen(false)} onShow={setMuscleDemo} onAdd={action => { setMuscleOpen(false); setTrainingEditor({ date: selectedDate, seedAction: action }); }} /> : null}
      {/* 动作库保持挂载在训练编辑器下层：加入训练 / 查看动作后返回，筛选、搜索和滚动位置都还在。 */}
      {actionLibrary ? <AppSheet full title="力量动作库" label="力量动作库" onClose={() => setActionLibrary(false)} footer={null}><MuscleActionList pick={null} onShow={setMuscleDemo} onAdd={action => setTrainingEditor({ date: selectedDate, seedAction: action })} /></AppSheet> : null}
      {courseDatesOpen ? <PlanCourseDateSheet onClose={()=>setCourseDatesOpen(false)} /> : null}
      {trainingEditor ? <TrainingEditorSheet templates={plan} key={`${trainingEditor.date}:${trainingEditor.initial?.id ?? trainingEditor.template?.id ?? 'new-training'}`} {...trainingEditor} onClose={() => setTrainingEditor(null)} onSave={async entry => { const result = await saveScheduledEntry(entry, trainingEditor.initial); if (result.ok) { setCalendar(loadSchedule().entries); setSelectedDate(entry.date); setHomeRev(n => n + 1); } return result; }} /> : null}
      {timerPicker ? <SchedulePicker date={selectedDate} onClose={() => setTimerPicker(false)} onChoose={openScheduled} onAdd={() => { setTimerPicker(false); setTrainingEditor({ date: selectedDate }); }} /> : null}
      {executionEntryId && calendar.find(e => e.id === executionEntryId) ? <ScheduledTraining key={executionEntryId} entry={calendar.find(e => e.id === executionEntryId)!} plan={plan} onClose={() => setExecutionEntryId(null)} onEdit={() => { const entry = calendar.find(e => e.id === executionEntryId)!; setExecutionEntryId(null); editScheduled(entry); }} onChanged={() => { setCalendar(loadSchedule().entries); setHomeRev(n => n + 1); }} onResumeOther={id => { setExecutionEntryId(null); resumeSession(id); }} /> : null}
      {techniqueLibrary ? <AppSheet full title="跑步技术动作库" label="跑步技术动作库" onClose={() => setTechniqueLibrary(false)} footer={null}><Suspense fallback={<p>正在加载跑步技术…</p>}><RunningTechniqueLibrary/></Suspense></AppSheet> : null}
      {muscleDemo ? <DemoSheet id={muscleDemo} onClose={() => setMuscleDemo(null)} action={libraryDemoAction(muscleDemo)} /> : null}
      {pickerDemo ? <DemoSheet id={pickerDemo} onClose={() => setPickerDemo(null)} action={pickerDemoAction(pickerDemo)} /> : null}
      {formMove ? <Sheet title={displayName(formMove)} onClose={()=>setFormMove(null)}><ExerciseContent catalogId={formMove.catalogId} /></Sheet> : null}

      {profileOpen ? (
        <ProfileSheet
          initial={withCoachGoals(profile, loadCoach().goals)}
          onClose={() => setProfileOpen(false)}
          onSave={(next) => {
            saveProfile(next);
            setProfile(next);
            const memory = loadCoach();
            const goals = goalsFromProfile(next);
            const managed = new Set(next.marks.map((mark) => mark.meters));
            const rest = memory.goals.filter((goal) => !managed.has(goal.meters));
            const coachOk = saveCoach({ ...memory, minutes: next.minutes, goals: [...goals, ...rest] });
            setProfileOpen(false);
            setNotice(coachOk ? "个人情况已保存。教练会按这些目标和晚上的时间看。" : COACH_SAVE_FAIL);
          }}
        />
      ) : null}
      {trainingImportOpen ? <TrainingImportSheet onClose={() => setTrainingImportOpen(false)} /> : null}
      {coachPlanOpen ? <CoachPlanSheet key={currentAthleteId()} profile={profile} onEditProfile={() => { setCoachPlanOpen(false); setProfileOpen(true); }} onClose={() => setCoachPlanOpen(false)} /> : null}

    </div>
  );
}

function CycleCard({ plan, onAdvance }: { plan: Plan; onAdvance: () => void }) {
  const cycle = plan.cycle ?? { block: 1, week: 1 as const, logs: [], lastChange: "" };
  const phase = phaseOf(cycle.week);
  const required = cycle.week === 4 && plan.sessions.length > 2 ? plan.sessions.slice(0, -1) : plan.sessions;
  const done = required.filter((item) => cycle.logs.some((log) => log.sessionId === item.id)).length;
  const total = required.length;
  const ready = weekReady(plan);
  return (
    <div className="mt-4">
      <p className="text-sm font-bold">当前周期</p>
      <div className="mt-1 flex items-baseline justify-between gap-3">
        <p className="text-sm">{cycle.week === 4 ? `第 ${cycle.block} 周期 · 调整` : `第 ${cycle.week} / 4 周`}</p>
        <p className="text-sm text-accent">{phase.label}</p>
      </div>
      <div className="mt-2 flex gap-1" aria-hidden="true">
        {PHASES.map((item) => (
          <span key={item.week} className={"h-1.5 flex-1 rounded-full " + (item.week <= cycle.week ? "bg-accent" : "bg-line")} />
        ))}
      </div>
      <p className="mt-2 text-sm text-muted">{phase.note}</p>
      {cycle.bias === "hold" ? <p className="text-sm">下周先不加量。</p> : null}
      {cycle.bias === "deload" ? <p className="text-sm">下周少一组，主项留下。</p> : null}
      <p className="text-sm text-muted">本周反馈 {done}/{total}{ready ? "，可以进入下一步。" : "。练完记一下感觉。"}</p>
      {cycle.lastChange ? <p className="mt-1 text-sm">{cycle.lastChange}</p> : null}
      <button
        type="button"
        onClick={onAdvance}
        disabled={!ready}
        className={"mt-3 flex h-11 w-full items-center justify-center rounded-2xl text-sm font-bold " + (ready ? "bg-accent text-accent-fg" : "bg-surface-2 text-muted")}
      >
        {ready ? (cycle.week === 3 ? "进入 3–4 天调整" : cycle.week === 4 ? "开始下一个三周" : "按反馈生成下一周") : "先把这周的感觉记全"}
      </button>
    </div>
  );
}

function Sheet({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  return (
    <div className="fixed inset-0 z-30 flex flex-col bg-bg">
      <div className="flex items-center justify-between border-b border-line px-4 py-3">
        <h2 className="min-w-0 truncate text-lg font-bold">{title}</h2>
        <button type="button" onClick={onClose} className="grid size-10 shrink-0 place-items-center" aria-label="关闭">
          <X className="size-5" />
        </button>
      </div>
      <div className="flex-1 overflow-y-auto px-4 py-4">{children}</div>
    </div>
  );
}

function IconButton({ label, onClick, disabled, children }: { label: string; onClick: () => void; disabled?: boolean; children: ReactNode }) {
  return (
    <button type="button" aria-label={label} disabled={disabled} onClick={onClick} className={"grid size-11 place-items-center " + (disabled ? "text-muted/40" : "text-muted")}>
      {children}
    </button>
  );
}

function Toggle({ pressed, onClick, children }: { pressed: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button type="button" aria-pressed={pressed} onClick={onClick} className={"h-11 rounded-full px-3 text-sm font-bold " + (pressed ? "bg-accent text-accent-fg" : "bg-surface-2 text-muted")}>
      {children}
    </button>
  );
}

function Stepper({
  label,
  value,
  min,
  max,
  step,
  suffix,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  suffix?: string;
  onChange: (value: number) => void;
}) {
  const shown = Number.isInteger(value) ? String(value) : String(value);
  return (
    <div className="rounded-xl bg-surface-2 px-2 py-2">
      <p className="px-1 text-xs text-muted">{label}</p>
      <div className="mt-1 flex items-center justify-between">
        <button
          type="button"
          disabled={value <= min}
          className="grid size-11 place-items-center rounded-full bg-surface text-lg disabled:opacity-30"
          aria-label={`减少${label}`}
          onClick={() => onChange(round(Math.max(min, value - step)))}
        >
          −
        </button>
        <span className="text-sm font-bold">
          {shown}
          {suffix ? <span className="ml-0.5 text-xs font-medium text-muted">{suffix}</span> : null}
        </span>
        <button
          type="button"
          disabled={value >= max}
          className="grid size-11 place-items-center rounded-full bg-surface text-lg disabled:opacity-30"
          aria-label={`增加${label}`}
          onClick={() => onChange(round(Math.min(max, value + step)))}
        >
          +
        </button>
      </div>
    </div>
  );
}

function round(n: number): number {
  return Math.round(n * 2) / 2;
}

function StandaloneWelcome({ suspended = false }: { suspended?: boolean }) {
  const [show, setShow] = useState(false), [msg, setMsg] = useState("");
  useEffect(() => {
    const standalone = window.matchMedia("(display-mode: standalone)").matches || (navigator as Navigator & { standalone?: boolean }).standalone === true;
    let n = 0; for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i) ?? ""; if (/^(fr255-(food|body|plan|schedule)|fk-(plan400|garmin-acts|bodylab))/.test(k)) n++; }
    if (standalone && n === 0 && !localStorage.getItem("fk-welcome-standalone-v1")) setShow(true);
  }, []);
  if (!show || suspended) return null;
  const done = () => { localStorage.setItem("fk-welcome-standalone-v1", "1"); setShow(false); };
  return <div className="fixed inset-0 z-[60] overflow-y-auto bg-bg p-4" style={{ paddingTop: "calc(env(safe-area-inset-top) + 12px)" }} role="dialog" aria-label="欢迎">
    <h2 className="text-xl font-bold">欢迎使用主屏幕版方坤</h2>
    <p className="keep mt-1 text-sm text-muted">主屏幕版和 Safari 版的数据是分开存的。</p>
    <section className="fk-dash-card mt-3 p-3">
      <b>从 Safari 版迁移数据</b>
      <ol className="keep mt-1 list-decimal pl-5 text-xs text-muted"><li>在 Safari 打开方坤 → ⚙️ → 全部数据备份 → 一键导出 → 存储到「文件」</li><li>回到这里，点下面按钮选那个备份文件</li></ol>
      <label className="fk-orange-btn mt-2 flex min-h-11 cursor-pointer items-center justify-center rounded-xl font-bold">选择备份文件导入<input type="file" accept="application/json,.json" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; if (!f) return; try { const result = await importVault(f); setMsg(result.reason + (result.candidateId ? ` 待核副本编号：${result.candidateId}（可在备份中心下载）` : "")); } catch (err) { setMsg((err as Error).message); } }} /></label>
      {msg ? <p className="keep mt-1 text-xs" aria-live="polite">{msg}</p> : null}
    </section>
    <button type="button" className="mt-3 min-h-12 w-full rounded-xl bg-accent px-3 font-bold text-accent-fg" onClick={() => openDeviceSync()}>连接手表或运动软件</button>
    <button type="button" className="mt-3 min-h-11 w-full rounded-xl border border-line text-sm" onClick={done}>跳过，从头开始</button>
  </div>;
}

function StorageHint() {
  const [show, setShow] = useState(false);
  useEffect(() => { setShow(!localStorage.getItem("fk-storage-hint-v1")); }, []);
  if (!show) return null;
  return <section className="home-card mt-3 p-3 text-sm" aria-label="存储提示"><b>Safari 和主屏幕 App 的数据是分开的</b><p className="keep mt-1 text-xs text-muted">在 Safari 里记的数据，添加到主屏幕后不会自动出现。先在原来那边「全部数据备份 → 导出」，再到另一边「导入恢复」。</p><button type="button" className="fk-link mt-1 text-xs" onClick={() => { localStorage.setItem("fk-storage-hint-v1", "1"); setShow(false); }}>知道了</button></section>;
}

function ChromeMetrics() {
  useEffect(() => {
    const root = document.documentElement; const nav = document.querySelector<HTMLElement>(".ui03-dock");
    const navH = () => { const h = nav && getComputedStyle(nav).display !== "none" ? nav.getBoundingClientRect().height : 0; root.style.setProperty("--fk-nav-h", `${Math.round(h)}px`); };
    const kb = () => { const vv = window.visualViewport; const ae = document.activeElement as HTMLElement | null; const typing = !!ae && (ae.tagName === "INPUT" && !["range", "checkbox", "radio", "button", "file", "date", "datetime-local", "time", "month", "week", "color"].includes((ae as HTMLInputElement).type) || ae.tagName === "TEXTAREA" || ae.isContentEditable); root.classList.toggle("fk-kb", typing || (!!vv && vv.height < window.innerHeight * 0.75)); if (vv) { root.style.setProperty("--fk-kb-h", `${Math.max(0, Math.round(window.innerHeight - vv.height - vv.offsetTop))}px`); root.style.setProperty("--fk-vvh", `${Math.round(vv.height)}px`); root.style.setProperty("--fk-vvtop", `${Math.max(0, Math.round(vv.offsetTop))}px`); } };
    window.visualViewport?.addEventListener("scroll", kb);
    const sheet = () => root.classList.toggle("fk-sheet", !!document.querySelector('[role="dialog"]'));
    const ro = nav ? new ResizeObserver(navH) : null; if (nav && ro) ro.observe(nav);
    const mo = new MutationObserver(() => { sheet(); navH(); }); mo.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ["class"] });
    navH(); sheet(); kb();
    window.visualViewport?.addEventListener("resize", kb); document.addEventListener("focusin", kb); const settle = () => { [50, 200, 400, 800, 1500].forEach(ms => setTimeout(() => { kb(); const v = window.visualViewport; const a = document.activeElement as HTMLElement | null; const typing = !!a && (a.tagName === "INPUT" || a.tagName === "TEXTAREA" || a.isContentEditable); if (!typing && (!v || v.height >= window.innerHeight * 0.75) && (window.scrollY !== 0 || (v?.offsetTop ?? 0) !== 0)) window.scrollTo(0, 0); }, ms)); };
    document.addEventListener("focusout", settle); window.addEventListener("resize", () => { navH(); settle(); }); window.addEventListener("orientationchange", settle); document.addEventListener("visibilitychange", settle); window.addEventListener("pageshow", settle);
    return () => { ro?.disconnect(); mo.disconnect(); window.visualViewport?.removeEventListener("resize", kb); document.removeEventListener("focusin", kb); window.removeEventListener("resize", navH); };
  }, []);
  return null;
}

installChunkRecovery();
