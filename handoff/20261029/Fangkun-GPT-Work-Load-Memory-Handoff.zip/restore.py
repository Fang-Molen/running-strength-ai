"""Dry-run by default. Never overwrites divergent files or deletes user data."""
from pathlib import Path,PurePosixPath
import argparse,json,hashlib,subprocess,sys
p=argparse.ArgumentParser();p.add_argument('repository');p.add_argument('--apply',action='store_true');args=p.parse_args()
here=Path(__file__).resolve().parent;root=Path(args.repository).resolve();m=json.loads((here/'MANIFEST.json').read_text());sha=lambda x:hashlib.sha256(x).hexdigest()
r=subprocess.run(['git','rev-parse','HEAD'],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
if r.returncode or r.stdout.decode().strip()!=m['baseline']:sys.exit('Baseline HEAD does not match; inspect and integrate manually. No files changed.')
changes=[];conflicts=[]
for f in m['files']:
 rel=PurePosixPath(f['path'])
 if rel.is_absolute() or '..' in rel.parts:sys.exit('Unsafe manifest path')
 src=here/'changes'/f['path'];dest=root/f['path']
 if root not in dest.resolve().parents:sys.exit('Unsafe destination symlink')
 if sha(src.read_bytes())!=f['sha256']:sys.exit('Package checksum mismatch: '+f['path'])
 if dest.is_symlink():conflicts.append(f['path']);continue
 current=sha(dest.read_bytes()) if dest.is_file() else None
 if current==f['sha256']:continue
 if current!=f['baseSha256']:conflicts.append(f['path']);continue
 changes.append((src,dest,current))
if conflicts:print(json.dumps({'conflicts':conflicts,'changed':0},ensure_ascii=False,indent=2));sys.exit(2)
if args.apply:
 # Recheck all targets before writing; no partial overwrite on a known conflict.
 if any((sha(dst.read_bytes()) if dst.is_file() else None)!=before for _,dst,before in changes):sys.exit('Destination changed during check; no files written.')
 for src,dst,_ in changes:dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes())
print(json.dumps({'safeChanges':len(changes),'applied':args.apply,'conflicts':0}))
