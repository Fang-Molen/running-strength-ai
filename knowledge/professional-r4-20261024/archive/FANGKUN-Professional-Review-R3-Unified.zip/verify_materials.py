"""Structural material audit only. Does not run Fangkun or establish scientific validity."""
import json,pathlib,math
p=pathlib.Path(__file__).resolve().parent
load=lambda n:json.loads((p/n).read_text())
sources=load('sources.json')['sources']; rules=load('professional-rules.json')['rules']; cases=load('teaching-cases.json'); ranges=load('reference-ranges.json')['references']
sids={s['id'] for s in sources}; rids={r['id'] for r in rules}
checks={}
checks['unique_sources']=len(sids)==len(sources)
checks['unique_rules']=len(rids)==len(rules)
checks['unique_cases']=len({c['id'] for c in cases})==len(cases)
checks['rule_source_references']=all(set(r['sourceIds'])<=sids for r in rules)
checks['rule_fields']=all(all(r.get(k) for k in ['id','domain','trigger','requiredInputs','decision','insufficient','minimalQuestion','forbiddenInference','basisType','status']) for r in rules)
checks['no_automatic_execution']=all(r['autoExecute'] is False for r in rules)
checks['case_rule_references']=all(set(c['rules'])<=rids for c in cases)
checks['synthetic_label']=all(c['status']=='AUTHOR_WRITTEN_SYNTHETIC_NOT_MODEL_OUTPUT' for c in cases)
checks['range_source_references']=all(r['sourceId'] in sids for r in ranges)
checks['numeric_ranges']=all(len(c['range'])==2 and all(isinstance(v,(int,float)) and math.isfinite(v) for v in c['range']) and c['range'][0]<=c['range'][1] for r in ranges for c in r['contexts'] if 'range' in c)
# Independent arithmetic checks for educational examples only.
checks['example_arithmetic']=(230+240+250+260==980 and 20*8*2==320 and (48-60)/60==-0.2 and [60*5,60*7]==[300,420])
result={'status':'PASS' if all(checks.values()) else 'FAIL','scope':'material consistency only, not semantic/model/App/professional validation','counts':{'sources':len(sources),'rules':len(rules),'syntheticCases':len(cases)},'checks':checks,'paidModelCalls':0}
(p/'material-checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
raise SystemExit(0 if all(checks.values()) else 1)
