/** Standalone deterministic host controls. No clinical inference, network, persistence or dose generation. */
const key=f=>`${f.id}@${f.revision}`;
const relevant=(x,t)=>Array.isArray(x.tasks)&&x.tasks.some(v=>t.includes(v));
const nonempty=x=>typeof x==='string'&&x.trim().length>0;
export function context(c,maxBytes=60000){
 if(!c.athleteId||!Number.isFinite(Date.parse(c.asOf))||!Array.isArray(c.tasks)||!c.tasks.length)throw Error('INVALID_CONTEXT');
 const map=new Map();
 for(const f of c.facts){
  if(f.athleteId!==c.athleteId||!Number.isInteger(f.revision)||f.revision<1||!nonempty(f.id)||!Number.isFinite(Date.parse(f.at))||Date.parse(f.at)>Date.parse(c.asOf))throw Error('INVALID_FACT');
  if(map.has(key(f))&&JSON.stringify(map.get(key(f)))!==JSON.stringify(f))throw Error('CONFLICTING_REVISION');
  map.set(key(f),f);
 }
 for(const r of c.requiredRefs??[])if(!map.has(r))throw Error('MISSING_REQUIRED:'+r);
 const hypotheses=(c.hypotheses??[]).filter(x=>relevant(x,c.tasks));
 const deps=new Set([...(c.requiredRefs??[]),...hypotheses.flatMap(x=>x.evidenceRefs??[])]);
 for(const r of deps)if(!map.has(r))throw Error('MISSING_DEPENDENCY:'+r);
 const result={schema:'FK-R2',athleteId:c.athleteId,asOf:c.asOf,tasks:c.tasks,
 facts:[...map.values()].filter(x=>deps.has(key(x))||x.safety||x.conflict||x.unfavorable||relevant(x,c.tasks)),
 requiredRefs:c.requiredRefs??[],restrictions:c.restrictions??[],conflicts:c.conflicts??[],
 hypotheses,candidates:(c.candidates??[]).filter(x=>relevant(x,c.tasks)),knowledge:c.knowledge??[]};
 if(new TextEncoder().encode(JSON.stringify(result)).length>maxBytes)throw Error('CONTEXT_BUDGET_EXCEEDED');
 return result;
}
export function validate(c,o){
 const errors=[], map=new Map(c.facts.map(f=>[key(f),f]));
 if(!o||!Array.isArray(o.facts))return ['INVALID_OUTPUT'];
 const used=new Set();
 for(const v of o.facts){const f=map.get(v.ref);if(!f){errors.push('UNKNOWN_REF:'+v.ref);continue;}if(v.value!==f.value||v.unit!==f.unit)errors.push('FACT_MISMATCH:'+v.ref);else used.add(v.ref);}
 for(const r of c.requiredRefs??[])if(!used.has(r))errors.push('MISSING_REQUIRED:'+r);
 for(const e of o.claims??[]){const f=map.get(e.factRef);if(!f||!['SUPPORTS','WEAKENS','UNKNOWN','IRRELEVANT'].includes(e.role)||!e.hypothesisId){errors.push('INVALID_RELATION');continue;}
 if(['SUPPORTS','WEAKENS'].includes(e.role)&&(f.value===null||f.value===undefined||f.kind==='prediction'||e.future))errors.push('NON_OBSERVED_EVIDENCE');
 if(e.role==='WEAKENS'&&f.kind==='deviceReadiness'&&e.claimKind==='localFunctionalLimitation')errors.push('READINESS_NOT_CLEARANCE');
 }
 for(const a of o.actions??[]){
 errors.push(...actionErrors(a,c.candidates??[]));
 if((a.basisRefs??[]).some(r=>!map.has(r)))errors.push('UNKNOWN_ACTION_REF');
 if(a.kind==='PROPOSE_CHANGE'&&((c.restrictions??[]).length||(c.conflicts??[]).length||!(c.candidates??[]).some(x=>x.id===a.optionId&&x.eligible===true)))errors.push('CHANGE_REQUIRES_REVIEW');
 }
 if(o.planChanged===true||o.persisted===true)errors.push('UNAUTHORIZED_WRITE_CLAIM');
 return errors;
}
export function prioritize(issues){return [...issues].sort((a,b)=>Number(!!b.safety)-Number(!!a.safety)||Number(!!b.goalRelevant)-Number(!!a.goalRelevant)||(b.confidence??0)-(a.confidence??0));}
export function purpose({completed,criteria=[]}){
 const usable=criteria.filter(x=>typeof x.met==='boolean'&&x.evidenceRefs?.length);
 return {completion:completed===true?'COMPLETED':completed===false?'NOT_COMPLETED':'UNKNOWN',purpose:usable.some(x=>!x.met)?'NOT_MET':criteria.length>0&&usable.length===criteria.length?'MET':'UNKNOWN',evidenceRefs:usable.flatMap(x=>x.evidenceRefs)};
}
export function options(list,limits){return list.map(o=>{
 const reasons=[];
 if(o.approved!==true)reasons.push('NOT_APPROVED');
 if(!Number.isFinite(limits.minutes)||!Number.isFinite(o.minutes)||o.minutes<0||o.minutes>limits.minutes)reasons.push('TIME_UNKNOWN_OR_EXCEEDED');
 if(!Array.isArray(o.equipment)||!Array.isArray(limits.equipment)||o.equipment.some(e=>!limits.equipment.includes(e)))reasons.push('EQUIPMENT_UNKNOWN_OR_MISSING');
 if(!Array.isArray(o.conflictIds)||!Array.isArray(limits.blockedIds)||o.conflictIds.some(x=>limits.blockedIds.includes(x)))reasons.push('CONFLICT_UNKNOWN_OR_PRESENT');
 return {...o,eligible:reasons.length===0,reasons,executionState:'PROPOSED'};
 });}
export function questions(list,knownFields,limit=2){return list.filter(x=>!knownFields.includes(x.field)&&x.changesDecision===true&&Array.isArray(x.branches)&&new Set(x.branches).size>=2).sort((a,b)=>(a.burden??Infinity)-(b.burden??Infinity)).slice(0,Math.max(0,limit));}
export function adherence(reason){const map={time:'MATCH_SHORTER_APPROVED_OPTION',equipment:'MATCH_AVAILABLE_OPTION',preference:'OFFER_EQUIVALENT_APPROVED_OPTION',technique:'REQUEST_TECHNIQUE_SUPPORT',pain:'DEFER_AND_REVIEW'};return {kind:map[reason]??'ASK_REASON',reason:reason??'UNKNOWN',trainingCleared:false};}
export function knowledge(rules,user){return rules.filter(r=>r.verified===true&&r.populations?.includes(user.population)&&r.sports?.includes(user.sport)&&Array.isArray(r.requiredConditions)&&Array.isArray(user.conditions)&&r.requiredConditions.every(x=>user.conditions.includes(x)));}
export function actionErrors(a,approvedOptions){
 const e=[];
 if(!['REQUEST_DATA','OBSERVE_EXISTING_PLAN','PROPOSE_CHANGE','DEFER_AND_REVIEW'].includes(a.kind))e.push('INVALID_ACTION');
 for(const name of ['purpose','instruction','reviewTrigger','changesJudgmentWhen'])if(!nonempty(a[name]))e.push('MISSING_ACTION_'+name);
 if(!Array.isArray(a.basisRefs)||!a.basisRefs.length)e.push('MISSING_ACTION_BASIS');
 if(a.kind==='REQUEST_DATA'&&(!a.neededInformation?.length||a.trainingCleared===true))e.push(a.trainingCleared?'NO_CLEARANCE_FROM_REQUEST':'MISSING_QUESTION');
 if(a.kind==='PROPOSE_CHANGE'&&(!approvedOptions.some(o=>o.id===a.optionId&&o.approved===true)||!nonempty(a.changedVariable)))e.push('UNAPPROVED_CHANGE');
 if(a.executionState&&a.executionState!=='PROPOSED')e.push('ACTION_NOT_PROPOSAL');
 return e;
}
export function revision(old,currentVersions,proposal){
 if(proposal.previousVersion!==old.version)throw Error('VERSION_CONFLICT');
 const stale=(old.evidenceRefs??[]).some(r=>{const i=r.lastIndexOf('@'),id=r.slice(0,i),v=Number(r.slice(i+1));return currentVersions[id]!==v;});
 if(!stale&&(!['SUPPORTED_MORE','WEAKENED','UNCHANGED','WITHDRAWAL_PROPOSED'].includes(proposal.change)||!nonempty(proposal.reason)||!proposal.newEvidenceRefs?.length))throw Error('INVALID_REVISION');
 return {hypothesisId:old.id,previousVersion:old.version,change:stale?'RECOMPUTE_REQUIRED':proposal.change,reason:proposal.reason,newEvidenceRefs:proposal.newEvidenceRefs??[],priorEvidenceRefs:[...(old.evidenceRefs??[])],persisted:false};
}
export async function run(c,generate){
 let input;try{input=context(c);}catch(e){return {status:'INPUT_REVIEW_REQUIRED',reason:e.message,trainingCleared:false};}
 const fallback=errors=>({status:'FACTUAL_FALLBACK',facts:input.facts.filter(f=>input.requiredRefs.includes(key(f))).map(f=>({ref:key(f),value:f.value,unit:f.unit})),errors,trainingCleared:false,planChanged:false});
 try{const answer=await generate(input);const errors=validate(input,answer);return errors.length?fallback(errors):{status:'STRUCTURALLY_VALID_SEMANTICS_UNVERIFIED',answer,planChanged:false};}catch{return fallback(['GENERATION_FAILED']);}
}
