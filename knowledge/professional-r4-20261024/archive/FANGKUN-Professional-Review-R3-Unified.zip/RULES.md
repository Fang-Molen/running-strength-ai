# 专业决策规则卡

研究候选；不是已验证模型能力或临床标准。ENGINEERING/PRODUCT为设计选择，METHOD为方法建议，来源不等于已验证个人效果。

## R01 身份与事实

- 触发：多人或多设备资料
- 输入：athleteId、eventTime、timeZone、sourceId、revision
- 决策：先隔离用户、保留事件时间与同步时间；冲突字段逐项核对
- 不足处理：不能确认属于谁或哪一天时，不进入个人画像
- 最小追问：只追问冲突身份或日期
- 禁止：把朋友PB当本人能力
- 依据类型：ENGINEERING；来源：本包工程/产品设计，非实证处方。

## R02 任务与目标

- 触发：用户提出训练/饮食问题
- 输入：requestedOutcome、primaryGoal、secondaryGoal、goalPriority
- 决策：先匹配所问任务；复合目标保留优先级和冲突
- 不足处理：目标冲突未解决时，给取舍选项而非悄悄替用户决定
- 最小追问：只问会改变方案的主目标
- 禁止：减脂用户一律给比赛补给模板
- 依据类型：PRODUCT；来源：本包工程/产品设计，非实证处方。

## R03 能力画像

- 触发：初始评估或更新能力
- 输入：event、verifiedPerformance、protocol、trainingHistory
- 决策：按专项、力量、技术、耐受分项陈述已知与未知
- 不足处理：单一成绩只支持相应条件的表现，不推导所有能力
- 最小追问：优先补最影响目标的缺项
- 禁止：跑得快就认定能承受更大力量量
- 依据类型：METHOD；来源：S07。

## R04 个人基线

- 触发：与历史比较
- 输入：metricDefinition、device、protocol、preAsOfRecords、context
- 决策：按可比情境生成描述基线；当前值与未来值不纳入参照
- 不足处理：样本不足仅描述已有记录，不编造正常区间
- 最小追问：缺设备/协议则先核对
- 禁止：同等级用户共享相同HRV基线
- 依据类型：METHOD；来源：S06。

## R05 换设备与漂移

- 触发：设备/算法/阶段改变
- 输入：oldSource、newSource、overlap、baselineVersion
- 决策：将新旧分段；有可验证桥接才换算，保留长期锚点与近期趋势
- 不足处理：无桥接时停止数值跨设备结论，仍可做同源分析
- 最小追问：问切换日期，不要求重填所有历史
- 禁止：滚动均值把持续恶化吸收为健康
- 依据类型：METHOD；来源：S06。

## R06 训练目的

- 触发：课后复盘
- 输入：declaredPurpose、planSnapshot、actual、criterionVersion
- 决策：分别输出完成情况、刺激执行证据和适应效果证据
- 不足处理：无预声明判据时目的达成为UNKNOWN，单课不证明长期适应
- 最小追问：问本课目的或关键执行条件
- 禁止：全部跑完等于有效提升能力
- 依据类型：PRODUCT；来源：本包工程/产品设计，非实证处方。

## R07 跑步可比性

- 触发：间歇/成绩比较
- 输入：distance、time、start、timing、rest、surface、conditions、purpose
- 决策：先比较相同协议；不匹配的只作参考，掉速由代码计算
- 不足处理：距离/组休/计时缺失时不下能力退步结论
- 最小追问：优先问组休或计时变化
- 禁止：把4×200和2轮4×200展平成同课
- 依据类型：METHOD；来源：S07。

## R08 专项周期

- 触发：安排未来训练
- 输入：event、eventDate、phase、recentToleratedWork、keySession、availability
- 决策：以主项目和阶段选择已批准课程，先排关键课再配支持课
- 不足处理：资料不足时不给完整确定配速或冠军训练量
- 最小追问：问近期实际与可用时间中最缺的一项
- 禁止：固定每周三次强度适用于所有人
- 依据类型：METHOD；来源：S07。

## R09 疲劳解释

- 触发：状态或表现变化
- 输入：comparablePerformance、subjectiveState、loadContext、sleep、HRMetric
- 决策：先区分测量/情境、执行变化、可能疲劳；允许多个原因共存
- 不足处理：单HRV/心率/准备度只作线索，不能宣布恢复或诊断
- 最小追问：问能区分解释的最小信息
- 禁止：HRV正常排除腿部疲劳
- 依据类型：METHOD；来源：S06, S08。

## R10 负荷评估

- 触发：周/月负担变化
- 输入：window、units、denominator、coverage、formulaVersion
- 决策：分别报告跑量、强度暴露、力量组数、sRPE等口径
- 不足处理：缺日记录不是休息0；负荷比不生成伤病概率
- 最小追问：核对分母与记录覆盖
- 禁止：ACWR超过1.3就一律减半
- 依据类型：METHOD；来源：S05。

## R11 疼痛与限制

- 触发：用户报告疼痛或功能受限
- 输入：symptoms、function、existingRestrictions
- 决策：保留限制并转人工/专业评估路径，不允许准备度覆盖限制
- 不足处理：没有临床解除依据时不输出康复完成或参赛许可
- 最小追问：只补影响即时处理的症状事实
- 禁止：设备90分即批准疼痛冲刺
- 依据类型：PRODUCT；来源：S04。

## R12 睡眠与生活

- 触发：睡眠差/出差/压力
- 输入：sleepOpportunity、subjectiveSleep、travel、schedule、source
- 决策：考虑训练和生活安排；与个人可比记录一起解释
- 不足处理：单夜或设备睡眠分不直接推算比赛损失
- 最小追问：问是否与实际感受/作息相符
- 禁止：固定八小时以下自动取消训练
- 依据类型：METHOD；来源：S08。

## R13 力量目标

- 触发：新建或修改力量课
- 输入：goal、experience、equipment、approvedTemplate、restrictions
- 决策：分清一般健康、力量、增肌、爆发力、跑步支持；选对应课程
- 不足处理：没有合格模板不填虚构组次/重量/休息
- 最小追问：问经验或器材限制
- 禁止：增肌十组规则强塞赛前800m运动员
- 依据类型：METHOD；来源：S01。

## R14 力量进阶

- 触发：完成力量后要求加重
- 输入：actualSets、reps、loadConvention、rest、RIR_RPE、technique、repeatExposure
- 决策：核对同动作同条件表现和执行质量，再选择原计划允许的一个进阶变量
- 不足处理：未知RIR或缺技术资料不伪造；单次完成不证明长期耐受
- 最小追问：补最关键执行字段
- 禁止：只看总吨位高就判定力量变强
- 依据类型：PRODUCT；来源：S01。

## R15 动作替换

- 触发：器材/偏好限制
- 输入：movementPurpose、availableEquipment、skill、restrictions、approvedAlternatives
- 决策：按动作目的与负担选择可执行替代，并说明不完全等价之处
- 不足处理：找不到合格替代则保留缺项，不按同一肌群随便替换
- 最小追问：问器材或不会做的环节
- 禁止：深蹲和腿伸展只因同肌群就完全等价
- 依据类型：PRODUCT；来源：S01。

## R16 跑力协调

- 触发：同日/相邻日跑步力量
- 输入：keyOutcome、calendar、sessionPurposes、localExposure、priorResponse
- 决策：比较维持、换序、分开、替代几个已批准选项，展示关键课影响
- 不足处理：不能从群体研究生成固定个人恢复小时数
- 最小追问：问哪个课是当前关键课
- 禁止：间隔3小时保证无干扰
- 依据类型：METHOD；来源：S02。

## R17 热身与短时课

- 触发：用户选择5/15/30-40分钟
- 输入：sessionType、keyTask、totalTime、approvedWarmup
- 决策：分别选跑前/力量前热身模板；区分总训练时间与热身时间
- 不足处理：不足以完成所选课准备时换批准的短课，不硬压所有动作
- 最小追问：问可用时长指热身还是整课
- 禁止：同一热身表机械缩短适用所有项目
- 依据类型：PRODUCT；来源：本包工程/产品设计，非实证处方。

## R18 漏练重排

- 触发：错过训练或比赛日期变化
- 输入：missedPurpose、newCalendar、keySessions、approvedAlternatives
- 决策：保留目标优先级并重排候选，明确删除/延期内容
- 不足处理：不自动补双倍、挤掉恢复或静默改变比赛目标
- 最小追问：问剩余可用时段
- 禁止：周三没练周四加倍补
- 依据类型：PRODUCT；来源：本包工程/产品设计，非实证处方。

## R19 饮食完整性

- 触发：饮食记录和营养汇总
- 输入：food、portion、cookedState、nutrientSource、dayCoverage
- 决策：按已确认记录计算已知摄入与缺项；照片/名称先匹配候选和份量
- 不足处理：不完整日记不判断全天不足，未知营养不当0
- 最小追问：问其余餐次或份量中最影响判断的一项
- 禁止：早餐400kcal推断全天缺1600kcal
- 依据类型：ENGINEERING；来源：本包工程/产品设计，非实证处方。

## R20 能量口径

- 触发：手表和饮食能量对比
- 输入：totalVsActiveEnergy、exerciseIncluded、intakeCoverage、weightTrend
- 决策：明确总/活动/净消耗口径，只使用不重复的估计路线
- 不足处理：没有口径不把活动消耗再加到含运动的总量
- 最小追问：核对设备字段语义
- 禁止：总消耗2400再加已含其中的跑步600
- 依据类型：ENGINEERING；来源：本包工程/产品设计，非实证处方。

## R21 营养方案

- 触发：用户要控重/增肌/表现饮食
- 输入：goal、activityContext、bodyMass、allergies、foodAccess、healthScope
- 决策：用带来源且情境匹配的参考范围提出餐食方向，再由份量数据库落地
- 不足处理：不强制最高范围；不完整数据不生成精准热量赤字
- 最小追问：只补影响份量/过敏/目标的字段
- 禁止：所有人固定459g碳水
- 依据类型：METHOD；来源：S03, S09, S10。

## R22 营养冲突与风险

- 触发：减重目标与表现/健康限制冲突
- 输入：goalPriority、intakeCoverage、symptoms、clinicalRestrictions
- 决策：先说明目标冲突；保留健康限制；需要临床处理时转专业人员
- 不足处理：不以单一能量可用性数值诊断REDs，不自动增大赤字
- 最小追问：核对记录后再讨论目标选择
- 禁止：用一日体重下降认定减脂成功
- 依据类型：PRODUCT；来源：S04。

## R23 补剂

- 触发：用户要求补剂或比赛补给
- 输入：event、need、medicalContext、productVerification
- 决策：优先常规食物和既有方案；补剂另行核对需求、风险与规则
- 不足处理：没有可靠资料不编剂量，不承诺产品无污染
- 最小追问：问具体产品和用途
- 禁止：营养不完整先推补剂套餐
- 依据类型：METHOD；来源：S03。

## R24 原因与反证

- 触发：解释掉速/疲劳/停滞
- 输入：hypothesis、evidenceRefs、alternativeConditions
- 决策：每命题单独标支持/削弱/未知，寻找真正区分解释的观察
- 不足处理：缺失不是反证；关联不等于因果；不凑固定两种解释
- 最小追问：只问可能改变当前解释的信息
- 禁止：未来可能变好被写成现有反证
- 依据类型：ENGINEERING；来源：本包工程/产品设计，非实证处方。

## R25 长期响应

- 触发：多次训练后的个人规律
- 输入：comparableExposures、responseTimes、confounders、corrections
- 决策：保存可核对关联及适用条件，新记录更新支持/削弱
- 不足处理：不从一次异常永久贴标签；不为证明假设诱导高风险试验
- 最小追问：优先利用已有正常训练观察
- 禁止：一次没睡好就判定此人不耐强度
- 依据类型：METHOD；来源：本包工程/产品设计，非实证处方。

## R26 执行适配

- 触发：反复漏练或不执行建议
- 输入：reportedBarrier、availableTime、equipment、preferences
- 决策：区分不能做、不会做、不愿做和不适，给具体替代
- 不足处理：原因未知先问，不判断意志薄弱
- 最小追问：询问主要阻碍
- 禁止：漏练自动加提醒/加量惩罚
- 依据类型：PRODUCT；来源：S01。

## R27 知识选择

- 触发：检索到指南/模型或冲突
- 输入：source、version、population、outcome、scope、access、correction
- 决策：检索到段落不等于规则有效；范围重叠也不机械合并；冲突保留
- 不足处理：未读原文的数值和未审临床算法不能自动执行
- 最小追问：需要时定向补证据，而不是全库塞入
- 禁止：来源新就无条件覆盖更适合的人群研究
- 依据类型：ENGINEERING；来源：本包工程/产品设计，非实证处方。

## R28 解释与沟通

- 触发：生成用户回答
- 输入：task、knownFacts、decision、uncertainty、nextObservation
- 决策：先回答当前问题，再给两三个关键事实与下一步；依据可展开
- 不足处理：不能把简短变成无依据，也不能说已保存/已改课表
- 最小追问：无必要不追问
- 禁止：所有问题输出长篇热身与三天观察
- 依据类型：PRODUCT；来源：本包工程/产品设计，非实证处方。

## R29 更正与删除

- 触发：用户更改/撤销事实
- 输入：factRevision、derivedDependencies、hypothesisVersion、authorization
- 决策：依赖失效→重算→重审→版本提案；删除传播至缓存/画像
- 不足处理：写入失败不能显示成功，旧记录保留按授权政策
- 最小追问：只核对更正范围
- 禁止：修改份量后营养页与教练仍用旧值
- 依据类型：ENGINEERING；来源：本包工程/产品设计，非实证处方。

## R30 范围与放行

- 触发：准备上线某能力
- 输入：implemented、domainReviewed、behaviorEvidence、realWorkflow
- 决策：分能力记录证据和失败；规则/测试/效果三种状态分开
- 不足处理：未知不当合格；不拿其他模块高分抵消关键错误
- 最小追问：只补阻断项
- 禁止：16项结构测试通过等于专业教练
- 依据类型：ENGINEERING；来源：本包工程/产品设计，非实证处方。

